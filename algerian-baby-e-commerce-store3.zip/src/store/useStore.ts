import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Product, SAMPLE_PRODUCTS, Category, CATEGORIES, StoreCategory } from '../data/products';
import { DEFAULT_DELIVERY_FEES } from '../data/algeria';

export type Language = 'ar' | 'fr';

export interface DeliveryCompany {
  id: string;
  name: string;
  nameAr: string;
  logo: string;
  enabled: boolean;
  fees: Record<number, { home: number; desk: number }>;
}

export interface Order {
  id: string;
  productId: string;
  productNameAr: string;
  productNameFr: string;
  customerName: string;
  phone: string;
  wilayaId: number;
  wilayaName: string;
  commune: string;
  address: string;
  deliveryType: 'home' | 'desk';
  deliveryCompany: string;
  selectedVariations: Record<string, string>;
  quantity: number;
  unitPrice: number;
  shippingFee: number;
  totalPrice: number;
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled';
  createdAt: string;
  notes?: string;
}

export interface StoreSettings {
  storeNameAr: string;
  storeNameFr: string;
  adminUsername: string;
  adminPassword: string;
  primaryColor: string;
  secondaryColor: string;
  heroGradient: string;
  heroTitleAr?: string;
  heroTitleFr?: string;
  heroSubtitleAr?: string;
  heroSubtitleFr?: string;
  heroOffers?: Array<{
    id: string;
    titleAr: string;
    titleFr: string;
    subtitleAr: string;
    subtitleFr: string;
    badgeAr: string;
    badgeFr: string;
    emoji: string;
    gradient: string;
  }>;
  heroImageUrl?: string;
  heroBackgroundImageUrl?: string;
  heroImageWidth?: number;
  heroImageHeight?: number;
  logoUrl?: string;
  facebookPixelId?: string;
  googleSheetsUrl?: string;
  whatsappNumber?: string;
  whatsappNumbers?: string[];
  instagramUrl?: string;
  facebookUrl?: string;
}

interface StoreState {
  language: Language;
  products: Product[];
  categories: StoreCategory[];
  orders: Order[];
  deliveryCompanies: DeliveryCompany[];
  settings: StoreSettings;
  adminAuthenticated: boolean;
  searchQuery: string;
  selectedCategory: Category | 'all';
  
  // Actions
  setLanguage: (lang: Language) => void;
  setSearchQuery: (query: string) => void;
  setSelectedCategory: (cat: Category | 'all') => void;
  addCategory: (category: StoreCategory) => void;
  updateCategory: (categoryId: string, updates: Partial<StoreCategory>) => void;
  deleteCategory: (categoryId: string) => void;
  addOrder: (order: Order) => void;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  updateProduct: (productId: string, updates: Partial<Product>) => void;
  addProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;
  addDeliveryCompany: (company: DeliveryCompany) => void;
  updateDeliveryCompany: (companyId: string, updates: Partial<DeliveryCompany>) => void;
  updateSettings: (updates: Partial<StoreSettings>) => void;
  setAdminAuthenticated: (auth: boolean) => void;
}

const DEFAULT_DELIVERY_COMPANIES: DeliveryCompany[] = [
  {
    id: 'yalidine',
    name: 'Yalidine',
    nameAr: 'يالدين',
    logo: '🚚',
    enabled: true,
    fees: DEFAULT_DELIVERY_FEES,
  },
  {
    id: 'zaki',
    name: 'Zaki Express',
    nameAr: 'زاكي إكسبريس',
    logo: '📦',
    enabled: true,
    fees: Object.fromEntries(
      Object.entries(DEFAULT_DELIVERY_FEES).map(([k, v]) => [k, { home: v.home + 50, desk: v.desk + 30 }])
    ),
  },
  {
    id: 'ecotrack',
    name: 'Ecotrack',
    nameAr: 'إيكوتراك',
    logo: '🌿',
    enabled: true,
    fees: Object.fromEntries(
      Object.entries(DEFAULT_DELIVERY_FEES).map(([k, v]) => [k, { home: v.home - 50, desk: v.desk - 30 }])
    ),
  },
  {
    id: 'procolis',
    name: 'Procolis',
    nameAr: 'بروكوليس',
    logo: '📮',
    enabled: false,
    fees: DEFAULT_DELIVERY_FEES,
  },
  {
    id: 'guepex',
    name: 'Guepex',
    nameAr: 'قيبكس',
    logo: '⚡',
    enabled: true,
    fees: Object.fromEntries(
      Object.entries(DEFAULT_DELIVERY_FEES).map(([k, v]) => [k, { home: v.home + 100, desk: v.desk + 80 }])
    ),
  },
];

const DEFAULT_SETTINGS: StoreSettings = {
  storeNameAr: 'Baby-care DZ',
  storeNameFr: 'Baby-care DZ',
  adminUsername: 'tmstore',
  adminPassword: '071121',
  primaryColor: '#ec4899',
  secondaryColor: '#8b5cf6',
  heroGradient: 'from-pink-500 via-purple-500 to-indigo-600',
  heroTitleAr: 'كل ما يحتاجه طفلك',
  heroTitleFr: 'Tout ce dont votre bébé a besoin',
  heroSubtitleAr: 'جودة عالية • أسعار مناسبة • توصيل لكل الجزائر',
  heroSubtitleFr: 'Haute qualité • Prix abordables • Livraison partout en Algérie',
  heroOffers: [
    {
      id: 'offer-1',
      titleAr: 'كل ما يحتاجه طفلك',
      titleFr: 'Tout ce dont votre bébé a besoin',
      subtitleAr: 'جودة عالية • أسعار مناسبة • توصيل لكل الجزائر',
      subtitleFr: 'Haute qualité • Prix abordables • Livraison partout en Algérie',
      badgeAr: 'أفضل متجر للأطفال',
      badgeFr: 'Meilleure boutique bébé',
      emoji: '👶',
      gradient: 'from-pink-500 via-rose-400 to-purple-600',
    },
    {
      id: 'offer-2',
      titleAr: 'إكسسوارات عصرية',
      titleFr: 'Accessoires Tendance',
      subtitleAr: 'أحدث صيحات الموضة لطفلك',
      subtitleFr: 'Les dernières tendances pour votre bébé',
      badgeAr: 'كولكشن جديد',
      badgeFr: 'Nouvelle collection',
      emoji: '✨',
      gradient: 'from-purple-600 via-indigo-500 to-blue-600',
    },
  ],
  heroImageUrl: '/hero-baby.jpg',
  heroBackgroundImageUrl: '',
  heroImageWidth: 320,
  heroImageHeight: 224,
  whatsappNumber: '0770000000',
  whatsappNumbers: ['0770000000'],
  facebookPixelId: '',
  googleSheetsUrl: '',
};

export const useStore = create<StoreState>()(
  persist(
    (set) => ({
      language: 'ar',
      products: SAMPLE_PRODUCTS,
      categories: CATEGORIES,
      orders: [],
      deliveryCompanies: DEFAULT_DELIVERY_COMPANIES,
      settings: DEFAULT_SETTINGS,
      adminAuthenticated: false,
      searchQuery: '',
      selectedCategory: 'all',

      setLanguage: (lang) => set({ language: lang }),
      setSearchQuery: (query) => set({ searchQuery: query }),
      setSelectedCategory: (cat) => set({ selectedCategory: cat }),

      addCategory: (category) => set((state) => ({
        categories: [...state.categories, category],
      })),

      updateCategory: (categoryId, updates) => set((state) => ({
        categories: state.categories.map(c => c.id === categoryId ? { ...c, ...updates } : c),
      })),

      deleteCategory: (categoryId) => set((state) => {
        const remainingCategories = state.categories.filter(c => c.id !== categoryId);
        const fallbackCategory = remainingCategories[0]?.id || 'uncategorized';
        return {
          categories: remainingCategories,
          selectedCategory: state.selectedCategory === categoryId ? 'all' : state.selectedCategory,
          products: state.products.map(p => p.category === categoryId ? { ...p, category: fallbackCategory } : p),
        };
      }),
      
      addOrder: (order) => set((state) => ({ orders: [order, ...state.orders] })),
      
      updateOrderStatus: (orderId, status) => set((state) => ({
        orders: state.orders.map(o => o.id === orderId ? { ...o, status } : o),
      })),
      
      updateProduct: (productId, updates) => set((state) => ({
        products: state.products.map(p => p.id === productId ? { ...p, ...updates } : p),
      })),
      
      addProduct: (product) => set((state) => ({
        products: [product, ...state.products],
      })),
      
      deleteProduct: (productId) => set((state) => ({
        products: state.products.filter(p => p.id !== productId),
      })),

      addDeliveryCompany: (company) => set((state) => ({
        deliveryCompanies: [...state.deliveryCompanies, company],
      })),
      
      updateDeliveryCompany: (companyId, updates) => set((state) => ({
        deliveryCompanies: state.deliveryCompanies.map(c => 
          c.id === companyId ? { ...c, ...updates } : c
        ),
      })),
      
      updateSettings: (updates) => set((state) => ({
        settings: { ...state.settings, ...updates },
      })),
      
      setAdminAuthenticated: (auth) => set({ adminAuthenticated: auth }),
    }),
    {
      name: 'baby-care-dz-store',
    }
  )
);
