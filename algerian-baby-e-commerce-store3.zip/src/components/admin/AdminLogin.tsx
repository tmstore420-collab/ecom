import React, { useState } from 'react';
import { Lock, Eye, EyeOff, ShieldCheck, User } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { useTranslation } from '../../hooks/useTranslation';

const AdminLogin: React.FC = () => {
  const { settings, setAdminAuthenticated } = useStore();
  const { t, isRTL } = useTranslation();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    await new Promise(r => setTimeout(r, 800));
    const validUsername = settings.adminUsername || 'tmstore';
    const validPassword = settings.adminPassword || '071121';
    if (username.trim() === validUsername && password === validPassword) {
      setAdminAuthenticated(true);
    } else {
      setError(isRTL ? 'اسم المستخدم أو رمز الدخول غير صحيح' : 'Nom utilisateur ou code incorrect');
    }
    setLoading(false);
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-pink-900 flex items-center justify-center p-4 ${isRTL ? 'font-cairo' : 'font-poppins'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 -left-20 w-72 h-72 bg-pink-500/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 -right-20 w-72 h-72 bg-purple-500/20 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Card */}
        <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 border border-white/20 shadow-2xl">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-pink-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-xl">
              <ShieldCheck size={36} className="text-white" />
            </div>
            <h1 className="text-2xl font-black text-white mb-1">Baby-care DZ</h1>
            <p className="text-white/60 text-sm">{t('adminLogin')}</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-white/80 text-sm font-medium mb-2">
                {isRTL ? 'اسم الأدمن' : 'Nom admin'}
              </label>
              <div className="relative">
                <User size={18} className={`absolute top-1/2 -translate-y-1/2 ${isRTL ? 'right-4' : 'left-4'} text-white/40`} />
                <input
                  type="text"
                  value={username}
                  onChange={e => { setUsername(e.target.value); setError(''); }}
                  className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-4 bg-white/10 border border-white/20 rounded-2xl text-white placeholder-white/30 focus:outline-none focus:border-pink-400 transition-colors`}
                  placeholder="tmstore"
                  dir="ltr"
                />
              </div>
            </div>

            <div>
              <label className="block text-white/80 text-sm font-medium mb-2">
                {isRTL ? 'رمز الدخول' : t('adminPassword')}
              </label>
              <div className="relative">
                <Lock size={18} className={`absolute top-1/2 -translate-y-1/2 ${isRTL ? 'right-4' : 'left-4'} text-white/40`} />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => { setPassword(e.target.value); setError(''); }}
                  className={`w-full ${isRTL ? 'pr-12 pl-12' : 'pl-12 pr-12'} py-4 bg-white/10 border border-white/20 rounded-2xl text-white placeholder-white/30 focus:outline-none focus:border-pink-400 transition-colors`}
                  placeholder="071121"
                  dir="ltr"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className={`absolute top-1/2 -translate-y-1/2 ${isRTL ? 'left-4' : 'right-4'} text-white/40 hover:text-white/70`}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
              {error && (
                <p className="text-red-400 text-sm mt-2 flex items-center gap-1">
                  <span>⚠️</span> {error}
                </p>
              )}
            </div>

            <button
              type="submit"
              disabled={loading || !username || !password}
              className="w-full bg-gradient-to-r from-pink-500 to-purple-600 text-white py-4 rounded-2xl font-black text-lg hover:shadow-2xl hover:scale-[1.02] transition-all duration-200 disabled:opacity-50 disabled:scale-100"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  {isRTL ? 'جاري التحقق...' : 'Vérification...'}
                </span>
              ) : t('loginBtn')}
            </button>
          </form>

          <p className="text-center text-white/30 text-xs mt-6">
            {isRTL ? 'للأدمن فقط • Baby-care DZ' : 'Admin uniquement • Baby-care DZ'}
          </p>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;
