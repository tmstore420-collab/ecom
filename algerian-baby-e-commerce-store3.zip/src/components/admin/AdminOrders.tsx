import React, { useState } from 'react';
import { Download, Search, Eye, X } from 'lucide-react';
import { useStore, Order } from '../../store/useStore';
import { useTranslation } from '../../hooks/useTranslation';
import * as XLSX from 'xlsx';

const STATUS_OPTIONS: Order['status'][] = ['pending', 'confirmed', 'shipped', 'delivered', 'cancelled'];

const AdminOrders: React.FC = () => {
  const { orders, updateOrderStatus } = useStore();
  const { isRTL } = useTranslation();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<Order['status'] | 'all'>('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [sortField, setSortField] = useState<'date' | 'total'>('date');

  const statusLabel = (s: Order['status']) => {
    const map: Record<Order['status'], { ar: string; fr: string; color: string }> = {
      pending: { ar: 'قيد الانتظار', fr: 'En attente', color: 'bg-yellow-100 text-yellow-700' },
      confirmed: { ar: 'مؤكد', fr: 'Confirmé', color: 'bg-blue-100 text-blue-700' },
      shipped: { ar: 'تم الشحن', fr: 'Expédié', color: 'bg-purple-100 text-purple-700' },
      delivered: { ar: 'تم التوصيل', fr: 'Livré', color: 'bg-green-100 text-green-700' },
      cancelled: { ar: 'ملغي', fr: 'Annulé', color: 'bg-red-100 text-red-700' },
    };
    return map[s];
  };

  const filtered = orders
    .filter(o => {
      const q = search.toLowerCase();
      return (
        (o.customerName.toLowerCase().includes(q) ||
          o.phone.includes(q) ||
          o.id.toLowerCase().includes(q) ||
          o.wilayaName.toLowerCase().includes(q)) &&
        (statusFilter === 'all' || o.status === statusFilter)
      );
    })
    .sort((a, b) => {
      if (sortField === 'date') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      return b.totalPrice - a.totalPrice;
    });

  const exportToExcel = () => {
    const data = orders.map(o => ({
      'رقم الطلب / Order ID': o.id,
      'الاسم / Nom': o.customerName,
      'الهاتف / Téléphone': o.phone,
      'الولاية / Wilaya': o.wilayaName,
      'البلدية / Commune': o.commune,
      'العنوان / Adresse': o.address,
      'المنتج / Produit': o.productNameAr,
      'الكمية / Quantité': o.quantity,
      'السعر / Prix': o.unitPrice,
      'التوصيل / Livraison': o.shippingFee,
      'المجموع / Total': o.totalPrice,
      'نوع التوصيل / Type livraison': o.deliveryType === 'home' ? 'منزل/Domicile' : 'مكتب/Bureau',
      'شركة التوصيل / Livreur': o.deliveryCompany,
      'الحالة / Statut': statusLabel(o.status)[isRTL ? 'ar' : 'fr'],
      'ملاحظات / Notes': o.notes || '',
      'التاريخ / Date': new Date(o.createdAt).toLocaleDateString('ar-DZ'),
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Commandes');

    // Auto column width
    const wscols = Object.keys(data[0] || {}).map(k => ({ wch: Math.max(k.length, 15) }));
    ws['!cols'] = wscols;

    XLSX.writeFile(wb, `baby-care-dz-orders-${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  return (
    <div className="space-y-6" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-gray-800">
            {isRTL ? 'إدارة الطلبات' : 'Gestion des commandes'}
          </h2>
          <p className="text-gray-500 text-sm mt-1">
            {orders.length} {isRTL ? 'طلب إجمالي' : 'commandes au total'}
          </p>
        </div>
        <button
          onClick={exportToExcel}
          disabled={orders.length === 0}
          className="flex items-center gap-2 bg-green-600 text-white px-5 py-3 rounded-xl font-bold hover:bg-green-700 transition-colors disabled:opacity-50"
        >
          <Download size={18} />
          {isRTL ? 'تصدير Excel' : 'Exporter Excel'}
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className={`absolute top-1/2 -translate-y-1/2 ${isRTL ? 'right-3' : 'left-3'} text-gray-400`} />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder={isRTL ? 'بحث بالاسم، الهاتف، رقم الطلب...' : 'Rechercher par nom, téléphone, ID...'}
            className={`w-full ${isRTL ? 'pr-9 pl-3' : 'pl-9 pr-3'} py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 text-sm`}
          />
        </div>
        <select
          value={statusFilter}
          onChange={e => setStatusFilter(e.target.value as any)}
          className="px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 text-sm bg-white"
        >
          <option value="all">{isRTL ? 'جميع الحالات' : 'Tous les statuts'}</option>
          {STATUS_OPTIONS.map(s => (
            <option key={s} value={s}>{statusLabel(s)[isRTL ? 'ar' : 'fr']}</option>
          ))}
        </select>
        <select
          value={sortField}
          onChange={e => setSortField(e.target.value as any)}
          className="px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 text-sm bg-white"
        >
          <option value="date">{isRTL ? 'الأحدث' : 'Plus récent'}</option>
          <option value="total">{isRTL ? 'الأعلى قيمة' : 'Valeur la plus haute'}</option>
        </select>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        {filtered.length === 0 ? (
          <div className="text-center py-16 text-gray-400">
            <div className="text-5xl mb-3">📦</div>
            <p className="font-medium">{isRTL ? 'لا توجد طلبات' : 'Aucune commande'}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b border-gray-100">
                <tr>
                  {[
                    isRTL ? 'رقم الطلب' : 'N° Commande',
                    isRTL ? 'العميل' : 'Client',
                    isRTL ? 'الولاية' : 'Wilaya',
                    isRTL ? 'المنتج' : 'Produit',
                    isRTL ? 'المجموع' : 'Total',
                    isRTL ? 'التوصيل' : 'Livraison',
                    isRTL ? 'الحالة' : 'Statut',
                    isRTL ? 'إجراءات' : 'Actions',
                  ].map((h, i) => (
                    <th key={i} className="text-right px-4 py-3 font-bold text-gray-600 whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filtered.map(order => {
                  const sl = statusLabel(order.status);
                  return (
                    <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-4 py-3 font-mono text-xs text-gray-500">
                        #{order.id.slice(-8)}
                      </td>
                      <td className="px-4 py-3">
                        <div className="font-medium text-gray-800">{order.customerName}</div>
                        <div className="text-xs text-gray-400">{order.phone}</div>
                      </td>
                      <td className="px-4 py-3 text-gray-600">{order.wilayaName}</td>
                      <td className="px-4 py-3">
                        <div className="font-medium text-gray-800 max-w-[150px] truncate">
                          {isRTL ? order.productNameAr : order.productNameFr}
                        </div>
                        <div className="text-xs text-gray-400">× {order.quantity}</div>
                      </td>
                      <td className="px-4 py-3 font-bold text-pink-600 whitespace-nowrap">
                        {order.totalPrice.toLocaleString()} دج
                      </td>
                      <td className="px-4 py-3 text-gray-600 text-xs">
                        <div>{order.deliveryCompany}</div>
                        <div className="text-gray-400">{order.deliveryType === 'home' ? '🏠' : '🏢'}</div>
                      </td>
                      <td className="px-4 py-3">
                        <select
                          value={order.status}
                          onChange={e => updateOrderStatus(order.id, e.target.value as Order['status'])}
                          className={`text-xs px-2 py-1.5 rounded-lg border font-medium cursor-pointer ${sl.color} border-current/20`}
                        >
                          {STATUS_OPTIONS.map(s => (
                            <option key={s} value={s}>{statusLabel(s)[isRTL ? 'ar' : 'fr']}</option>
                          ))}
                        </select>
                      </td>
                      <td className="px-4 py-3">
                        <button
                          onClick={() => setSelectedOrder(order)}
                          className="p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition-colors"
                          title={isRTL ? 'عرض التفاصيل' : 'Voir détails'}
                        >
                          <Eye size={16} />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Order Detail Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setSelectedOrder(null)}>
          <div
            className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            dir={isRTL ? 'rtl' : 'ltr'}
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-black text-gray-800">
                {isRTL ? 'تفاصيل الطلب' : 'Détails commande'}
              </h3>
              <button onClick={() => setSelectedOrder(null)} className="p-2 hover:bg-gray-100 rounded-xl">
                <X size={20} />
              </button>
            </div>

            <div className="space-y-4 text-sm">
              <div className="bg-gray-50 rounded-xl p-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-500">{isRTL ? 'رقم الطلب' : 'N° Commande'}</span>
                  <span className="font-mono font-bold text-xs">{selectedOrder.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">{isRTL ? 'التاريخ' : 'Date'}</span>
                  <span>{new Date(selectedOrder.createdAt).toLocaleDateString('ar-DZ')}</span>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-bold text-gray-700">{isRTL ? '👤 معلومات العميل' : '👤 Client'}</h4>
                <div className="bg-blue-50 rounded-xl p-4 space-y-1">
                  <p><span className="text-gray-500">{isRTL ? 'الاسم: ' : 'Nom: '}</span><strong>{selectedOrder.customerName}</strong></p>
                  <p><span className="text-gray-500">{isRTL ? 'الهاتف: ' : 'Tél: '}</span><strong dir="ltr">{selectedOrder.phone}</strong></p>
                  <p><span className="text-gray-500">{isRTL ? 'الولاية: ' : 'Wilaya: '}</span>{selectedOrder.wilayaName}</p>
                  <p><span className="text-gray-500">{isRTL ? 'البلدية: ' : 'Commune: '}</span>{selectedOrder.commune}</p>
                  <p><span className="text-gray-500">{isRTL ? 'العنوان: ' : 'Adresse: '}</span>{selectedOrder.address}</p>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-bold text-gray-700">{isRTL ? '📦 تفاصيل الطلب' : '📦 Commande'}</h4>
                <div className="bg-pink-50 rounded-xl p-4 space-y-1">
                  <p><span className="text-gray-500">{isRTL ? 'المنتج: ' : 'Produit: '}</span>{isRTL ? selectedOrder.productNameAr : selectedOrder.productNameFr}</p>
                  <p><span className="text-gray-500">{isRTL ? 'الكمية: ' : 'Quantité: '}</span>{selectedOrder.quantity}</p>
                  <p><span className="text-gray-500">{isRTL ? 'السعر: ' : 'Prix: '}</span>{selectedOrder.unitPrice.toLocaleString()} دج</p>
                  <p><span className="text-gray-500">{isRTL ? 'التوصيل: ' : 'Livraison: '}</span>{selectedOrder.shippingFee.toLocaleString()} دج</p>
                  <p className="border-t border-pink-100 pt-1 mt-1"><span className="text-gray-500">{isRTL ? 'المجموع: ' : 'Total: '}</span><strong className="text-pink-600">{selectedOrder.totalPrice.toLocaleString()} دج</strong></p>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-bold text-gray-700">{isRTL ? '🚚 التوصيل' : '🚚 Livraison'}</h4>
                <div className="bg-purple-50 rounded-xl p-4 space-y-1">
                  <p><span className="text-gray-500">{isRTL ? 'الشركة: ' : 'Société: '}</span>{selectedOrder.deliveryCompany}</p>
                  <p><span className="text-gray-500">{isRTL ? 'النوع: ' : 'Type: '}</span>{selectedOrder.deliveryType === 'home' ? (isRTL ? '🏠 منزل' : '🏠 Domicile') : (isRTL ? '🏢 مكتب' : '🏢 Bureau')}</p>
                </div>
              </div>

              {selectedOrder.notes && (
                <div className="bg-gray-50 rounded-xl p-3">
                  <p className="text-gray-500 text-xs mb-1">{isRTL ? 'ملاحظات:' : 'Notes:'}</p>
                  <p className="text-gray-700">{selectedOrder.notes}</p>
                </div>
              )}

              <div className="flex gap-3 pt-2">
                <select
                  value={selectedOrder.status}
                  onChange={e => {
                    updateOrderStatus(selectedOrder.id, e.target.value as Order['status']);
                    setSelectedOrder({ ...selectedOrder, status: e.target.value as Order['status'] });
                  }}
                  className="flex-1 px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-pink-400"
                >
                  {STATUS_OPTIONS.map(s => (
                    <option key={s} value={s}>{statusLabel(s)[isRTL ? 'ar' : 'fr']}</option>
                  ))}
                </select>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="px-4 py-2 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors"
                >
                  {isRTL ? 'إغلاق' : 'Fermer'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminOrders;
