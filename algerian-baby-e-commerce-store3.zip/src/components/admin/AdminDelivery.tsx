import React, { useState } from 'react';
import { Plus, Save, ChevronDown, ChevronUp, ToggleLeft, ToggleRight } from 'lucide-react';
import { DeliveryCompany, useStore } from '../../store/useStore';
import { useTranslation } from '../../hooks/useTranslation';
import { WILAYAS } from '../../data/algeria';

const AdminDelivery: React.FC = () => {
  const { deliveryCompanies, addDeliveryCompany, updateDeliveryCompany } = useStore();
  const { isRTL } = useTranslation();
  const [expandedCompany, setExpandedCompany] = useState<string | null>(null);
  const [editingFees, setEditingFees] = useState<Record<string, Record<number, { home: number; desk: number }>>>({});
  const [newCompany, setNewCompany] = useState({ name: '', nameAr: '', logo: '🚚', homeFee: 600, deskFee: 450 });
  const [savedMsg, setSavedMsg] = useState<string | null>(null);

  const getFee = (companyId: string, wilayaId: number, type: 'home' | 'desk'): number => {
    if (editingFees[companyId]?.[wilayaId]) {
      return editingFees[companyId][wilayaId][type];
    }
    const company = deliveryCompanies.find(c => c.id === companyId);
    return company?.fees[wilayaId]?.[type] || 0;
  };

  const updateFee = (companyId: string, wilayaId: number, type: 'home' | 'desk', value: number) => {
    setEditingFees(prev => {
      const existing = prev[companyId]?.[wilayaId] || {
        home: getFee(companyId, wilayaId, 'home'),
        desk: getFee(companyId, wilayaId, 'desk'),
      };
      return {
        ...prev,
        [companyId]: {
          ...prev[companyId],
          [wilayaId]: { ...existing, [type]: value },
        },
      };
    });
  };

  const saveCompanyFees = (companyId: string) => {
    const company = deliveryCompanies.find(c => c.id === companyId);
    if (!company) return;

    const updatedFees = { ...company.fees };
    if (editingFees[companyId]) {
      Object.entries(editingFees[companyId]).forEach(([wId, fees]) => {
        updatedFees[parseInt(wId)] = fees;
      });
    }

    updateDeliveryCompany(companyId, { fees: updatedFees });
    setEditingFees(prev => {
      const next = { ...prev };
      delete next[companyId];
      return next;
    });
    setSavedMsg(isRTL ? 'تم الحفظ بنجاح!' : 'Sauvegardé!');
    setTimeout(() => setSavedMsg(null), 2000);
  };

  const applyBulkFee = (companyId: string, homeAdd: number, deskAdd: number) => {
    const company = deliveryCompanies.find(c => c.id === companyId);
    if (!company) return;
    const newFees: Record<number, { home: number; desk: number }> = {};
    WILAYAS.forEach(w => {
      const existing = company.fees[w.id] || { home: 500, desk: 400 };
      newFees[w.id] = {
        home: Math.max(0, existing.home + homeAdd),
        desk: Math.max(0, existing.desk + deskAdd),
      };
    });
    updateDeliveryCompany(companyId, { fees: newFees });
  };

  const handleAddCompany = () => {
    if (!newCompany.name.trim() || !newCompany.nameAr.trim()) return;
    const fees = Object.fromEntries(
      WILAYAS.map(w => [w.id, { home: newCompany.homeFee, desk: newCompany.deskFee }])
    ) as Record<number, { home: number; desk: number }>;
    const company: DeliveryCompany = {
      id: `delivery-${Date.now()}`,
      name: newCompany.name.trim(),
      nameAr: newCompany.nameAr.trim(),
      logo: newCompany.logo || '🚚',
      enabled: true,
      fees,
    };
    addDeliveryCompany(company);
    setNewCompany({ name: '', nameAr: '', logo: '🚚', homeFee: 600, deskFee: 450 });
    setSavedMsg(isRTL ? 'تمت إضافة شركة التوصيل' : 'Société ajoutée');
    setTimeout(() => setSavedMsg(null), 2000);
  };

  return (
    <div className="space-y-6" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div>
        <h2 className="text-2xl font-black text-gray-800">
          {isRTL ? 'إعدادات شركات التوصيل' : 'Paramètres de livraison'}
        </h2>
        <p className="text-gray-500 text-sm mt-1">
          {isRTL ? 'إدارة شركات التوصيل والأسعار لكل ولاية' : 'Gérez les sociétés de livraison et les prix par wilaya'}
        </p>
      </div>

      {/* Success Message */}
      {savedMsg && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl font-medium">
          ✅ {savedMsg}
        </div>
      )}

      {/* Add Delivery Company */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
        <h3 className="font-black text-gray-800 mb-4 flex items-center gap-2">
          <Plus size={20} className="text-pink-600" />
          {isRTL ? 'إضافة شركة توصيل' : 'Ajouter une société de livraison'}
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
          <input
            type="text"
            value={newCompany.nameAr}
            onChange={e => setNewCompany(p => ({ ...p, nameAr: e.target.value }))}
            className="px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
            placeholder={isRTL ? 'الاسم بالعربية' : 'Nom arabe'}
          />
          <input
            type="text"
            value={newCompany.name}
            onChange={e => setNewCompany(p => ({ ...p, name: e.target.value }))}
            className="px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
            placeholder={isRTL ? 'الاسم بالفرنسية/لاتيني' : 'Nom'}
          />
          <input
            type="text"
            value={newCompany.logo}
            onChange={e => setNewCompany(p => ({ ...p, logo: e.target.value }))}
            className="px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 text-center"
            placeholder="🚚"
          />
          <input
            type="number"
            value={newCompany.homeFee}
            onChange={e => setNewCompany(p => ({ ...p, homeFee: parseFloat(e.target.value) || 0 }))}
            className="px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
            placeholder={isRTL ? 'سعر المنزل' : 'Prix domicile'}
          />
          <input
            type="number"
            value={newCompany.deskFee}
            onChange={e => setNewCompany(p => ({ ...p, deskFee: parseFloat(e.target.value) || 0 }))}
            className="px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
            placeholder={isRTL ? 'سعر المكتب' : 'Prix bureau'}
          />
          <button
            type="button"
            onClick={handleAddCompany}
            className="bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-xl font-bold px-4 py-2.5 hover:shadow-lg transition-all"
          >
            {isRTL ? 'إضافة' : 'Ajouter'}
          </button>
        </div>
      </div>

      {/* Companies */}
      <div className="space-y-4">
        {deliveryCompanies.map(company => (
          <div key={company.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            {/* Company Header */}
            <div className="p-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="text-3xl">{company.logo}</div>
                  <div>
                    <h3 className="font-black text-gray-800 text-lg">
                      {isRTL ? company.nameAr : company.name}
                    </h3>
                    <p className="text-sm text-gray-500">
                      {isRTL ? company.name : company.nameAr}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  {/* Toggle Enabled */}
                  <button
                    onClick={() => updateDeliveryCompany(company.id, { enabled: !company.enabled })}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl font-medium text-sm transition-all ${
                      company.enabled 
                        ? 'bg-green-100 text-green-700 hover:bg-green-200' 
                        : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                    }`}
                  >
                    {company.enabled 
                      ? <ToggleRight size={20} className="text-green-600" />
                      : <ToggleLeft size={20} />
                    }
                    {company.enabled 
                      ? (isRTL ? 'مفعّل' : 'Activé')
                      : (isRTL ? 'معطّل' : 'Désactivé')
                    }
                  </button>

                  {/* Expand */}
                  <button
                    onClick={() => setExpandedCompany(expandedCompany === company.id ? null : company.id)}
                    className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
                  >
                    {expandedCompany === company.id ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                  </button>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-3 gap-3 mt-4">
                {[
                  { label: isRTL ? 'أقل سعر منزل' : 'Min domicile', value: `${Math.min(...Object.values(company.fees).map(f => f.home))} دج` },
                  { label: isRTL ? 'أكثر سعر منزل' : 'Max domicile', value: `${Math.max(...Object.values(company.fees).map(f => f.home))} دج` },
                  { label: isRTL ? 'أقل سعر مكتب' : 'Min bureau', value: `${Math.min(...Object.values(company.fees).map(f => f.desk))} دج` },
                ].map((s, i) => (
                  <div key={i} className="bg-gray-50 rounded-xl p-3 text-center">
                    <div className="font-bold text-gray-800 text-sm">{s.value}</div>
                    <div className="text-xs text-gray-500">{s.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Expanded Fees Table */}
            {expandedCompany === company.id && (
              <div className="border-t border-gray-100">
                {/* Bulk Actions */}
                <div className="p-4 bg-blue-50 border-b border-blue-100">
                  <p className="text-sm font-bold text-blue-700 mb-3">
                    {isRTL ? '⚡ تعديل سريع لجميع الولايات' : '⚡ Modification rapide toutes wilayas'}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {[50, 100, -50, -100].map(amount => (
                      <button
                        key={amount}
                        onClick={() => applyBulkFee(company.id, amount, Math.round(amount * 0.8))}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                          amount > 0 
                            ? 'bg-orange-100 text-orange-700 hover:bg-orange-200' 
                            : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                        }`}
                      >
                        {amount > 0 ? `+${amount}` : amount} {isRTL ? 'دج للكل' : 'DA tout'}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Wilaya Fees Table */}
                <div className="max-h-80 overflow-y-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50 sticky top-0">
                      <tr>
                        <th className="text-right px-4 py-2 font-bold text-gray-600">{isRTL ? 'الولاية' : 'Wilaya'}</th>
                        <th className="text-right px-4 py-2 font-bold text-gray-600">
                          🏠 {isRTL ? 'منزل (دج)' : 'Domicile (DA)'}
                        </th>
                        <th className="text-right px-4 py-2 font-bold text-gray-600">
                          🏢 {isRTL ? 'مكتب (دج)' : 'Bureau (DA)'}
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {WILAYAS.map(w => (
                        <tr key={w.id} className="hover:bg-gray-50">
                          <td className="px-4 py-2 text-gray-700">
                            <span className="text-gray-400 text-xs mr-1">{w.id.toString().padStart(2, '0')}.</span>
                            {isRTL ? w.nameAr : w.nameFr}
                          </td>
                          <td className="px-4 py-2">
                            <input
                              type="number"
                              value={getFee(company.id, w.id, 'home')}
                              onChange={e => updateFee(company.id, w.id, 'home', parseFloat(e.target.value) || 0)}
                              className="w-24 px-2 py-1 border border-gray-200 rounded-lg text-center focus:outline-none focus:border-pink-400 text-sm"
                            />
                          </td>
                          <td className="px-4 py-2">
                            <input
                              type="number"
                              value={getFee(company.id, w.id, 'desk')}
                              onChange={e => updateFee(company.id, w.id, 'desk', parseFloat(e.target.value) || 0)}
                              className="w-24 px-2 py-1 border border-gray-200 rounded-lg text-center focus:outline-none focus:border-pink-400 text-sm"
                            />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Save */}
                <div className="p-4 border-t border-gray-100">
                  <button
                    onClick={() => saveCompanyFees(company.id)}
                    className="flex items-center gap-2 bg-green-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-green-700 transition-colors"
                  >
                    <Save size={18} />
                    {isRTL ? 'حفظ أسعار التوصيل' : 'Sauvegarder les tarifs'}
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminDelivery;
