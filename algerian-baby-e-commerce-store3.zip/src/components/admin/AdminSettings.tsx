import React, { useState } from 'react';
import { Plus, Save, Palette, Link, Store, Lock, Trash2 } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { useTranslation } from '../../hooks/useTranslation';

const AdminSettings: React.FC = () => {
  const { settings, categories, addCategory, updateCategory, deleteCategory, updateSettings } = useStore();
  const { isRTL } = useTranslation();
  const [localSettings, setLocalSettings] = useState({ ...settings });
  const [newCategory, setNewCategory] = useState({ labelAr: '', labelFr: '', icon: '🛍️', color: 'from-pink-400 to-rose-400' });
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    updateSettings({
      ...localSettings,
      adminUsername: localSettings.adminUsername || 'tmstore',
      adminPassword: localSettings.adminPassword || '071121',
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleHeroImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = () => {
      setLocalSettings(p => ({ ...p, heroImageUrl: String(reader.result || '') }));
    };
    reader.readAsDataURL(file);
  };

  const handleHeroBackgroundUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = () => {
      setLocalSettings(p => ({ ...p, heroBackgroundImageUrl: String(reader.result || '') }));
    };
    reader.readAsDataURL(file);
  };

  const updateOffer = (offerId: string, updates: Partial<NonNullable<typeof localSettings.heroOffers>[number]>) => {
    setLocalSettings(p => ({
      ...p,
      heroOffers: (p.heroOffers || []).map(offer => offer.id === offerId ? { ...offer, ...updates } : offer),
    }));
  };

  const addOffer = () => {
    setLocalSettings(p => ({
      ...p,
      heroOffers: [
        ...(p.heroOffers || []),
        {
          id: `offer-${Date.now()}`,
          titleAr: 'عرض جديد',
          titleFr: 'Nouvelle offre',
          subtitleAr: 'اكتب تفاصيل العرض هنا',
          subtitleFr: 'Écrivez les détails de l\'offre ici',
          badgeAr: 'عرض خاص',
          badgeFr: 'Offre spéciale',
          emoji: '🎁',
          gradient: 'from-pink-500 via-purple-500 to-indigo-600',
        },
      ],
    }));
  };

  const removeOffer = (offerId: string) => {
    setLocalSettings(p => ({
      ...p,
      heroOffers: (p.heroOffers || []).filter(offer => offer.id !== offerId),
    }));
  };

  const handleAddCategory = () => {
    if (!newCategory.labelAr.trim() || !newCategory.labelFr.trim()) return;
    addCategory({
      id: `cat-${Date.now()}`,
      labelAr: newCategory.labelAr.trim(),
      labelFr: newCategory.labelFr.trim(),
      icon: newCategory.icon || '🛍️',
      color: newCategory.color,
    });
    setNewCategory({ labelAr: '', labelFr: '', icon: '🛍️', color: 'from-pink-400 to-rose-400' });
  };

  const GRADIENT_OPTIONS = [
    { value: 'from-pink-500 via-purple-500 to-indigo-600', label: isRTL ? 'وردي-بنفسجي' : 'Rose-Violet' },
    { value: 'from-rose-500 via-pink-500 to-fuchsia-600', label: isRTL ? 'وردي-فوشيا' : 'Rose-Fuchsia' },
    { value: 'from-orange-400 via-pink-500 to-rose-600', label: isRTL ? 'برتقالي-وردي' : 'Orange-Rose' },
    { value: 'from-blue-500 via-indigo-500 to-purple-600', label: isRTL ? 'أزرق-بنفسجي' : 'Bleu-Violet' },
    { value: 'from-teal-400 via-cyan-500 to-blue-600', label: isRTL ? 'فيروزي-أزرق' : 'Turquoise-Bleu' },
    { value: 'from-green-400 via-emerald-500 to-teal-600', label: isRTL ? 'أخضر-زمردي' : 'Vert-Émeraude' },
    { value: 'from-yellow-400 via-orange-500 to-red-600', label: isRTL ? 'أصفر-أحمر' : 'Jaune-Rouge' },
    { value: 'from-violet-500 via-purple-600 to-indigo-700', label: isRTL ? 'بنفسجي-نيلي' : 'Violet-Indigo' },
  ];

  const CATEGORY_COLORS = [
    'from-pink-400 to-rose-400',
    'from-purple-400 to-violet-400',
    'from-blue-400 to-cyan-400',
    'from-green-400 to-emerald-400',
    'from-yellow-400 to-orange-400',
    'from-fuchsia-400 to-pink-400',
    'from-indigo-400 to-blue-400',
    'from-slate-400 to-gray-500',
  ];

  return (
    <div className="space-y-6 max-w-5xl" dir={isRTL ? 'rtl' : 'ltr'}>
      <div>
        <h2 className="text-2xl font-black text-gray-800">
          {isRTL ? 'إعدادات المتجر' : 'Paramètres du magasin'}
        </h2>
        <p className="text-gray-500 text-sm mt-1">
          {isRTL ? 'تخصيص مظهر وإعدادات متجرك' : 'Personnalisez l\'apparence et les paramètres de votre magasin'}
        </p>
      </div>

      {saved && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl font-medium">
          ✅ {isRTL ? 'تم حفظ الإعدادات بنجاح!' : 'Paramètres sauvegardés avec succès!'}
        </div>
      )}

      {/* Admin Access */}
      <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
        <h3 className="flex items-center gap-2 font-black text-gray-800 mb-5 text-lg">
          <Lock size={20} className="text-gray-700" />
          {isRTL ? 'بيانات دخول الأدمن' : 'Accès administrateur'}
        </h3>
        <p className="text-sm text-gray-500 mb-4">
          {isRTL
            ? 'الإعدادات مخفية في المتجر. اضغط 5 مرات على كتابة Baby-care DZ لفتح صفحة الدخول.'
            : 'Les paramètres sont cachés. Cliquez 5 fois sur le texte Baby-care DZ pour ouvrir la connexion.'}
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">
              {isRTL ? 'اسم الأدمن' : 'Nom admin'}
            </label>
            <input
              type="text"
              value={localSettings.adminUsername || 'tmstore'}
              onChange={e => setLocalSettings(p => ({ ...p, adminUsername: e.target.value }))}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
              placeholder="tmstore"
              dir="ltr"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">
              {isRTL ? 'رمز الدخول' : 'Code d\'accès'}
            </label>
            <input
              type="text"
              value={localSettings.adminPassword || '071121'}
              onChange={e => setLocalSettings(p => ({ ...p, adminPassword: e.target.value }))}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
              placeholder="071121"
              dir="ltr"
            />
          </div>
        </div>
      </div>

      {/* Store Info */}
      <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
        <h3 className="flex items-center gap-2 font-black text-gray-800 mb-5 text-lg">
          <Store size={20} className="text-pink-600" />
          {isRTL ? 'معلومات المتجر' : 'Informations du magasin'}
        </h3>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1.5">
                {isRTL ? 'اسم المتجر (عربي)' : 'Nom magasin (Arabe)'}
              </label>
              <input
                type="text"
                value={localSettings.storeNameAr}
                onChange={e => setLocalSettings(p => ({ ...p, storeNameAr: e.target.value }))}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1.5">
                {isRTL ? 'اسم المتجر (فرنسي)' : 'Nom magasin (Français)'}
              </label>
              <input
                type="text"
                value={localSettings.storeNameFr}
                onChange={e => setLocalSettings(p => ({ ...p, storeNameFr: e.target.value }))}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">
              📱 {isRTL ? 'أرقام واتساب' : 'Numéros WhatsApp'}
            </label>
            <textarea
              rows={3}
              value={(localSettings.whatsappNumbers?.length ? localSettings.whatsappNumbers : [localSettings.whatsappNumber || '']).filter(Boolean).join('\n')}
              onChange={e => {
                const numbers = e.target.value.split(/\n|,/).map(n => n.trim()).filter(Boolean);
                setLocalSettings(p => ({ ...p, whatsappNumbers: numbers, whatsappNumber: numbers[0] || '' }));
              }}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
              placeholder={'0770000000\n0550000000'}
              dir="ltr"
            />
            <p className="text-xs text-gray-400 mt-1">
              {isRTL ? 'ضع كل رقم في سطر منفصل.' : 'Un numéro par ligne.'}
            </p>
          </div>
        </div>
      </div>

      {/* Appearance */}
      <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
        <h3 className="flex items-center gap-2 font-black text-gray-800 mb-5 text-lg">
          <Palette size={20} className="text-purple-600" />
          {isRTL ? 'المظهر والألوان' : 'Apparence et couleurs'}
        </h3>
        <div className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1.5">
                {isRTL ? 'عنوان الواجهة الرئيسي (عربي)' : 'Titre hero (Arabe)'}
              </label>
              <input
                type="text"
                value={localSettings.heroTitleAr || ''}
                onChange={e => setLocalSettings(p => ({ ...p, heroTitleAr: e.target.value }))}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1.5">
                {isRTL ? 'عنوان الواجهة الرئيسي (فرنسي)' : 'Titre hero (Français)'}
              </label>
              <input
                type="text"
                value={localSettings.heroTitleFr || ''}
                onChange={e => setLocalSettings(p => ({ ...p, heroTitleFr: e.target.value }))}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1.5">
                {isRTL ? 'النص الفرعي (عربي)' : 'Sous-titre (Arabe)'}
              </label>
              <input
                type="text"
                value={localSettings.heroSubtitleAr || ''}
                onChange={e => setLocalSettings(p => ({ ...p, heroSubtitleAr: e.target.value }))}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1.5">
                {isRTL ? 'النص الفرعي (فرنسي)' : 'Sous-titre (Français)'}
              </label>
              <input
                type="text"
                value={localSettings.heroSubtitleFr || ''}
                onChange={e => setLocalSettings(p => ({ ...p, heroSubtitleFr: e.target.value }))}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-600 mb-2">
              {isRTL ? 'صورة الواجهة الرئيسية' : 'Image de la page d\'accueil'}
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-[150px_1fr] gap-3">
              <label className="flex h-28 cursor-pointer items-center justify-center rounded-xl border-2 border-dashed border-pink-200 bg-pink-50 text-center text-sm font-bold text-pink-600 hover:bg-pink-100 transition-colors">
                <input type="file" accept="image/*" onChange={handleHeroImageUpload} className="hidden" />
                {isRTL ? 'رفع صورة' : 'Importer'}
              </label>
              {localSettings.heroImageUrl ? (
                <img src={localSettings.heroImageUrl} alt="hero preview" className="h-28 w-full rounded-xl object-cover border border-gray-100" />
              ) : (
                <div className="h-28 rounded-xl bg-gray-50 border border-gray-100 flex items-center justify-center text-gray-400 text-sm">
                  {isRTL ? 'لا توجد صورة' : 'Aucune image'}
                </div>
              )}
            </div>
            <input
              type="url"
              value={localSettings.heroImageUrl || ''}
              onChange={e => setLocalSettings(p => ({ ...p, heroImageUrl: e.target.value }))}
              className="mt-3 w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
              placeholder="https://..."
              dir="ltr"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-600 mb-2">
              {isRTL ? 'خلفية الواجهة بصورة' : 'Image de fond de la page d\'accueil'}
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-[150px_1fr] gap-3">
              <label className="flex h-24 cursor-pointer items-center justify-center rounded-xl border-2 border-dashed border-purple-200 bg-purple-50 text-center text-sm font-bold text-purple-600 hover:bg-purple-100 transition-colors">
                <input type="file" accept="image/*" onChange={handleHeroBackgroundUpload} className="hidden" />
                {isRTL ? 'رفع خلفية' : 'Importer fond'}
              </label>
              {localSettings.heroBackgroundImageUrl ? (
                <img src={localSettings.heroBackgroundImageUrl} alt="background preview" className="h-24 w-full rounded-xl object-cover border border-gray-100" />
              ) : (
                <div className="h-24 rounded-xl bg-gray-50 border border-gray-100 flex items-center justify-center text-gray-400 text-sm">
                  {isRTL ? 'لا توجد خلفية صورة' : 'Aucune image de fond'}
                </div>
              )}
            </div>
            <input
              type="url"
              value={localSettings.heroBackgroundImageUrl || ''}
              onChange={e => setLocalSettings(p => ({ ...p, heroBackgroundImageUrl: e.target.value }))}
              className="mt-3 w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
              placeholder="https://..."
              dir="ltr"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-600 mb-2">
              {isRTL ? 'حجم صورة الواجهة' : 'Taille image hero'}
            </label>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="block text-xs text-gray-500 mb-1">{isRTL ? 'العرض px' : 'Largeur px'}</span>
                <input
                  type="number"
                  value={localSettings.heroImageWidth || 320}
                  onChange={e => setLocalSettings(p => ({ ...p, heroImageWidth: parseInt(e.target.value) || 320 }))}
                  className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
                />
              </div>
              <div>
                <span className="block text-xs text-gray-500 mb-1">{isRTL ? 'الارتفاع px' : 'Hauteur px'}</span>
                <input
                  type="number"
                  value={localSettings.heroImageHeight || 224}
                  onChange={e => setLocalSettings(p => ({ ...p, heroImageHeight: parseInt(e.target.value) || 224 }))}
                  className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-600 mb-3">
              {isRTL ? 'تدرج الخلفية الرئيسية' : 'Dégradé de la page d\'accueil'}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {GRADIENT_OPTIONS.map(opt => (
                <button
                  key={opt.value}
                  onClick={() => setLocalSettings(p => ({ ...p, heroGradient: opt.value }))}
                  className={`h-16 rounded-xl bg-gradient-to-r ${opt.value} border-4 transition-all font-bold text-white text-xs flex items-end justify-center pb-2 ${
                    localSettings.heroGradient === opt.value ? 'border-gray-800 scale-105 shadow-xl' : 'border-transparent'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Preview */}
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-2">
              {isRTL ? 'معاينة' : 'Aperçu'}
            </label>
            <div className={`h-24 rounded-2xl bg-gradient-to-r ${localSettings.heroGradient} flex items-center justify-center text-white font-black text-xl`}>
              {localSettings.storeNameAr || 'Baby-care DZ'}
            </div>
          </div>
        </div>
      </div>

      {/* Hero Offers */}
      <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
        <div className="flex items-center justify-between gap-3 mb-5">
          <h3 className="flex items-center gap-2 font-black text-gray-800 text-lg">
            <Palette size={20} className="text-pink-600" />
            {isRTL ? 'عروض الواجهة الرئيسية' : 'Offres de la page d\'accueil'}
          </h3>
          <button
            type="button"
            onClick={addOffer}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 text-white font-bold text-sm hover:shadow-lg transition-all"
          >
            <Plus size={16} />
            {isRTL ? 'إضافة عرض' : 'Ajouter'}
          </button>
        </div>
        <div className="space-y-4">
          {(localSettings.heroOffers || []).map((offer, index) => (
            <div key={offer.id} className="rounded-2xl border border-gray-100 bg-gray-50 p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="font-bold text-gray-700">{isRTL ? `عرض ${index + 1}` : `Offre ${index + 1}`}</span>
                <button
                  type="button"
                  onClick={() => removeOffer(offer.id)}
                  className="p-2 rounded-xl bg-red-50 text-red-500 hover:bg-red-100 disabled:opacity-40"
                  disabled={(localSettings.heroOffers || []).length <= 1}
                >
                  <Trash2 size={16} />
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input value={offer.titleAr} onChange={e => updateOffer(offer.id, { titleAr: e.target.value })} className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400" placeholder={isRTL ? 'عنوان عربي' : 'Titre arabe'} />
                <input value={offer.titleFr} onChange={e => updateOffer(offer.id, { titleFr: e.target.value })} className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400" placeholder={isRTL ? 'عنوان فرنسي' : 'Titre français'} />
                <input value={offer.subtitleAr} onChange={e => updateOffer(offer.id, { subtitleAr: e.target.value })} className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400" placeholder={isRTL ? 'نص فرعي عربي' : 'Sous-titre arabe'} />
                <input value={offer.subtitleFr} onChange={e => updateOffer(offer.id, { subtitleFr: e.target.value })} className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400" placeholder={isRTL ? 'نص فرعي فرنسي' : 'Sous-titre français'} />
                <input value={offer.badgeAr} onChange={e => updateOffer(offer.id, { badgeAr: e.target.value })} className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400" placeholder={isRTL ? 'شارة عربية' : 'Badge arabe'} />
                <input value={offer.badgeFr} onChange={e => updateOffer(offer.id, { badgeFr: e.target.value })} className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400" placeholder={isRTL ? 'شارة فرنسية' : 'Badge français'} />
                <input value={offer.emoji} onChange={e => updateOffer(offer.id, { emoji: e.target.value })} className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 text-center" placeholder="🎁" />
                <select value={offer.gradient} onChange={e => updateOffer(offer.id, { gradient: e.target.value })} className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 bg-white">
                  {GRADIENT_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                </select>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Categories */}
      <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
        <h3 className="flex items-center gap-2 font-black text-gray-800 mb-5 text-lg">
          <Plus size={20} className="text-pink-600" />
          {isRTL ? 'إدارة الفئات' : 'Gestion des catégories'}
        </h3>
        <p className="text-sm text-gray-500 mb-4">
          {isRTL ? 'يمكن تعديل اسم الفئة، الأيقونة، اللون، إضافة فئة أو حذفها.' : 'Modifiez le nom, l\'icône, la couleur, ajoutez ou supprimez une catégorie.'}
        </p>

        <div className="space-y-3 mb-5">
          {categories.map(category => (
            <div key={category.id} className="grid grid-cols-1 sm:grid-cols-[70px_1fr_1fr_1fr_auto] gap-2 items-center rounded-xl border border-gray-100 p-3">
              <input
                type="text"
                value={category.icon}
                onChange={e => updateCategory(category.id, { icon: e.target.value })}
                className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 text-center"
                placeholder="🛍️"
              />
              <input
                type="text"
                value={category.labelAr}
                onChange={e => updateCategory(category.id, { labelAr: e.target.value })}
                className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
                placeholder={isRTL ? 'اسم عربي' : 'Nom arabe'}
              />
              <input
                type="text"
                value={category.labelFr}
                onChange={e => updateCategory(category.id, { labelFr: e.target.value })}
                className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
                placeholder={isRTL ? 'اسم فرنسي' : 'Nom français'}
              />
              <select
                value={category.color}
                onChange={e => updateCategory(category.id, { color: e.target.value })}
                className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 bg-white"
              >
                {CATEGORY_COLORS.map(color => (
                  <option key={color} value={color}>{color.replace('from-', '').replace(' to-', ' / ')}</option>
                ))}
              </select>
              <button
                type="button"
                onClick={() => deleteCategory(category.id)}
                className="p-2 rounded-xl bg-red-50 text-red-500 hover:bg-red-100 transition-colors disabled:opacity-40"
                disabled={categories.length <= 1}
                title={isRTL ? 'حذف الفئة' : 'Supprimer'}
              >
                <Trash2 size={18} />
              </button>
            </div>
          ))}
        </div>

        <div className="rounded-2xl bg-gray-50 p-4 border border-gray-100">
          <h4 className="font-bold text-gray-700 mb-3">{isRTL ? 'إضافة فئة جديدة' : 'Ajouter une catégorie'}</h4>
          <div className="grid grid-cols-1 sm:grid-cols-[70px_1fr_1fr_1fr_auto] gap-2">
            <input
              type="text"
              value={newCategory.icon}
              onChange={e => setNewCategory(p => ({ ...p, icon: e.target.value }))}
              className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 text-center"
              placeholder="🛍️"
            />
            <input
              type="text"
              value={newCategory.labelAr}
              onChange={e => setNewCategory(p => ({ ...p, labelAr: e.target.value }))}
              className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
              placeholder={isRTL ? 'اسم عربي' : 'Nom arabe'}
            />
            <input
              type="text"
              value={newCategory.labelFr}
              onChange={e => setNewCategory(p => ({ ...p, labelFr: e.target.value }))}
              className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
              placeholder={isRTL ? 'اسم فرنسي' : 'Nom français'}
            />
            <select
              value={newCategory.color}
              onChange={e => setNewCategory(p => ({ ...p, color: e.target.value }))}
              className="px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 bg-white"
            >
              {CATEGORY_COLORS.map(color => (
                <option key={color} value={color}>{color.replace('from-', '').replace(' to-', ' / ')}</option>
              ))}
            </select>
            <button
              type="button"
              onClick={handleAddCategory}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 text-white font-bold hover:shadow-lg transition-all"
            >
              {isRTL ? 'إضافة' : 'Ajouter'}
            </button>
          </div>
        </div>
      </div>

      {/* Social & APIs */}
      <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
        <h3 className="flex items-center gap-2 font-black text-gray-800 mb-5 text-lg">
          <Link size={20} className="text-blue-600" />
          {isRTL ? 'التكاملات والروابط' : 'Intégrations et liens'}
        </h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">
              📘 {isRTL ? 'رقم Facebook Pixel' : 'ID Facebook Pixel'}
            </label>
            <input
              type="text"
              value={localSettings.facebookPixelId || ''}
              onChange={e => setLocalSettings(p => ({ ...p, facebookPixelId: e.target.value }))}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
              placeholder="1234567890"
              dir="ltr"
            />
            <p className="text-xs text-gray-400 mt-1">
              {isRTL ? 'يُستخدم لتتبع المبيعات والإعلانات على فيسبوك' : 'Utilisé pour suivre les ventes et les publicités Facebook'}
            </p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">
              📊 {isRTL ? 'رابط Google Sheets' : 'URL Google Sheets'}
            </label>
            <input
              type="url"
              value={localSettings.googleSheetsUrl || ''}
              onChange={e => setLocalSettings(p => ({ ...p, googleSheetsUrl: e.target.value }))}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
              placeholder="https://docs.google.com/spreadsheets/..."
              dir="ltr"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">
              📸 {isRTL ? 'رابط Instagram' : 'Lien Instagram'}
            </label>
            <input
              type="url"
              value={localSettings.instagramUrl || ''}
              onChange={e => setLocalSettings(p => ({ ...p, instagramUrl: e.target.value }))}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
              placeholder="https://instagram.com/..."
              dir="ltr"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">
              📘 {isRTL ? 'رابط Facebook' : 'Lien Facebook'}
            </label>
            <input
              type="url"
              value={localSettings.facebookUrl || ''}
              onChange={e => setLocalSettings(p => ({ ...p, facebookUrl: e.target.value }))}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400"
              placeholder="https://facebook.com/..."
              dir="ltr"
            />
          </div>
        </div>
      </div>

      {/* Facebook Pixel Script Info */}
      {localSettings.facebookPixelId && (
        <div className="bg-blue-50 rounded-2xl p-5 border border-blue-100">
          <h4 className="font-bold text-blue-800 mb-2">
            {isRTL ? '📋 كود Facebook Pixel' : '📋 Code Facebook Pixel'}
          </h4>
          <p className="text-blue-600 text-sm mb-3">
            {isRTL 
              ? 'أضف هذا الكود في index.html داخل <head>'
              : 'Ajoutez ce code dans index.html dans <head>'}
          </p>
          <pre className="bg-white p-3 rounded-xl text-xs text-gray-600 overflow-x-auto border border-blue-100" dir="ltr">
{`<script>
!function(f,b,e,v,n,t,s){...}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '${localSettings.facebookPixelId}');
fbq('track', 'PageView');
</script>`}
          </pre>
        </div>
      )}

      {/* Save Button */}
      <button
        onClick={handleSave}
        className="flex items-center gap-3 bg-gradient-to-r from-pink-500 to-purple-600 text-white px-8 py-4 rounded-2xl font-black text-lg hover:shadow-xl hover:scale-[1.02] transition-all"
      >
        <Save size={22} />
        {isRTL ? 'حفظ جميع الإعدادات' : 'Sauvegarder tous les paramètres'}
      </button>
    </div>
  );
};

export default AdminSettings;
