import React, { useState } from 'react';
import { Plus, Edit2, Trash2, Search, X, Save } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { useTranslation } from '../../hooks/useTranslation';
import { Product, Category } from '../../data/products';

const AdminProducts: React.FC = () => {
  const { products, categories, updateProduct, addProduct, deleteProduct } = useStore();
  const { isRTL } = useTranslation();
  const [search, setSearch] = useState('');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    nameAr: '',
    nameFr: '',
    descriptionAr: '',
    descriptionFr: '',
    price: '',
    discountPrice: '',
    stock: '',
      category: categories[0]?.id as Category || 'uncategorized',
    badge: '',
    bgColor: 'from-pink-100 to-rose-100',
    featured: false,
    images: [''],
  });

  const filtered = products.filter(p => {
    const q = search.toLowerCase();
    return p.nameAr.includes(q) || p.nameFr.toLowerCase().includes(q);
  });

  const openEdit = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      nameAr: product.nameAr,
      nameFr: product.nameFr,
      descriptionAr: product.descriptionAr,
      descriptionFr: product.descriptionFr,
      price: product.price.toString(),
      discountPrice: product.discountPrice?.toString() || '',
      stock: product.stock.toString(),
      category: product.category,
      badge: product.badge || '',
      bgColor: product.bgColor || 'from-pink-100 to-rose-100',
      featured: product.featured || false,
      images: product.images.length > 0 ? product.images : [''],
    });
  };

  const openAdd = () => {
    setEditingProduct(null);
    setFormData({
      nameAr: '',
      nameFr: '',
      descriptionAr: '',
      descriptionFr: '',
      price: '',
      discountPrice: '',
      stock: '',
      category: categories[0]?.id || 'uncategorized',
      badge: '',
      bgColor: 'from-pink-100 to-rose-100',
      featured: false,
      images: [''],
    });
    setShowAddModal(true);
  };

  const handleSave = () => {
    const productData: Partial<Product> = {
      nameAr: formData.nameAr,
      nameFr: formData.nameFr,
      descriptionAr: formData.descriptionAr,
      descriptionFr: formData.descriptionFr,
      price: parseFloat(formData.price) || 0,
      discountPrice: formData.discountPrice ? parseFloat(formData.discountPrice) : undefined,
      stock: parseInt(formData.stock) || 0,
      category: formData.category,
      badge: formData.badge || undefined,
      bgColor: formData.bgColor,
      featured: formData.featured,
      images: formData.images.filter(img => img.trim()),
    };

    if (editingProduct) {
      updateProduct(editingProduct.id, productData);
      setEditingProduct(null);
    } else {
      const newProduct: Product = {
        ...productData as any,
        id: Date.now().toString(),
        variations: [],
        tags: [],
      };
      addProduct(newProduct);
      setShowAddModal(false);
    }
  };

  const BG_OPTIONS = [
    { value: 'from-pink-100 to-rose-100', label: isRTL ? 'وردي' : 'Rose' },
    { value: 'from-purple-100 to-violet-100', label: isRTL ? 'بنفسجي' : 'Violet' },
    { value: 'from-blue-100 to-cyan-100', label: isRTL ? 'أزرق' : 'Bleu' },
    { value: 'from-green-100 to-emerald-100', label: isRTL ? 'أخضر' : 'Vert' },
    { value: 'from-yellow-100 to-orange-100', label: isRTL ? 'برتقالي' : 'Orange' },
    { value: 'from-fuchsia-100 to-pink-100', label: isRTL ? 'فوشيا' : 'Fuchsia' },
    { value: 'from-indigo-100 to-blue-100', label: isRTL ? 'نيلي' : 'Indigo' },
    { value: 'from-slate-100 to-gray-100', label: isRTL ? 'رمادي' : 'Gris' },
  ];

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []).filter(file => file.type.startsWith('image/'));
    if (files.length === 0) return;

    Promise.all(files.map(file => new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.readAsDataURL(file);
    }))).then(images => {
      setFormData(p => ({ ...p, images: [...p.images.filter(Boolean), ...images] }));
    });
  };

  const removeImage = (index: number) => {
    setFormData(p => ({ ...p, images: p.images.filter((_, i) => i !== index) }));
  };

  const ProductForm = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-600 mb-1">
            {isRTL ? 'الاسم بالعربية' : 'Nom (Arabe)'} *
          </label>
          <input
            type="text"
            value={formData.nameAr}
            onChange={e => setFormData(p => ({ ...p, nameAr: e.target.value }))}
            className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 text-sm"
            placeholder="اسم المنتج"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-600 mb-1">
            {isRTL ? 'الاسم بالفرنسية' : 'Nom (Français)'} *
          </label>
          <input
            type="text"
            value={formData.nameFr}
            onChange={e => setFormData(p => ({ ...p, nameFr: e.target.value }))}
            className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 text-sm"
            placeholder="Nom du produit"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-600 mb-1">
            {isRTL ? 'الوصف بالعربية' : 'Description (Arabe)'}
          </label>
          <textarea
            value={formData.descriptionAr}
            onChange={e => setFormData(p => ({ ...p, descriptionAr: e.target.value }))}
            rows={3}
            className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 text-sm resize-none"
            placeholder="وصف المنتج..."
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-600 mb-1">
            {isRTL ? 'الوصف بالفرنسية' : 'Description (Français)'}
          </label>
          <textarea
            value={formData.descriptionFr}
            onChange={e => setFormData(p => ({ ...p, descriptionFr: e.target.value }))}
            rows={3}
            className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 text-sm resize-none"
            placeholder="Description..."
          />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-600 mb-1">
            {isRTL ? 'السعر (دج)' : 'Prix (DA)'} *
          </label>
          <input
            type="number"
            value={formData.price}
            onChange={e => setFormData(p => ({ ...p, price: e.target.value }))}
            className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 text-sm"
            placeholder="2500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-600 mb-1">
            {isRTL ? 'سعر الخصم (دج)' : 'Prix remisé (DA)'}
          </label>
          <input
            type="number"
            value={formData.discountPrice}
            onChange={e => setFormData(p => ({ ...p, discountPrice: e.target.value }))}
            className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 text-sm"
            placeholder="1900"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-600 mb-1">
            {isRTL ? 'المخزون' : 'Stock'} *
          </label>
          <input
            type="number"
            value={formData.stock}
            onChange={e => setFormData(p => ({ ...p, stock: e.target.value }))}
            className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 text-sm"
            placeholder="50"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-600 mb-1">{isRTL ? 'الفئة' : 'Catégorie'}</label>
          <select
            value={formData.category}
            onChange={e => setFormData(p => ({ ...p, category: e.target.value as Category }))}
            className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 text-sm bg-white"
          >
            {categories.map(c => (
              <option key={c.id} value={c.id}>{c.icon} {isRTL ? c.labelAr : c.labelFr}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-600 mb-1">{isRTL ? 'شارة' : 'Badge'}</label>
          <input
            type="text"
            value={formData.badge}
            onChange={e => setFormData(p => ({ ...p, badge: e.target.value }))}
            className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 text-sm"
            placeholder={isRTL ? 'جديد، الأكثر مبيعاً...' : 'Nouveau, Bestseller...'}
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-600 mb-2">{isRTL ? 'لون الخلفية' : 'Couleur fond'}</label>
        <div className="flex flex-wrap gap-2">
          {BG_OPTIONS.map(opt => (
            <button
              key={opt.value}
              type="button"
              onClick={() => setFormData(p => ({ ...p, bgColor: opt.value }))}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium bg-gradient-to-r ${opt.value} border-2 transition-all ${
                formData.bgColor === opt.value ? 'border-gray-600 scale-105' : 'border-transparent'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-600 mb-1">
          {isRTL ? 'صورة المنتج' : 'Image produit'}
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-[120px_1fr] gap-3">
          <label className="flex h-24 cursor-pointer items-center justify-center rounded-xl border-2 border-dashed border-pink-200 bg-pink-50 text-center text-xs font-bold text-pink-600 hover:bg-pink-100 transition-colors">
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={handleImageUpload}
              className="hidden"
            />
            {isRTL ? 'رفع صور من الحاسوب' : 'Importer images'}
          </label>
          {formData.images.filter(Boolean).length ? (
            <div className="grid grid-cols-3 gap-2">
              {formData.images.filter(Boolean).map((image, index) => (
                <div key={`${image.slice(0, 18)}-${index}`} className="relative">
                  <img
                    src={image}
                    alt="preview"
                    className="h-24 w-full rounded-xl object-cover border border-gray-100"
                    onError={e => (e.currentTarget.style.display = 'none')}
                  />
                  <button
                    type="button"
                    onClick={() => removeImage(index)}
                    className="absolute top-1 left-1 w-6 h-6 rounded-full bg-red-500 text-white text-xs font-bold"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="h-24 rounded-xl bg-gray-50 border border-gray-100 flex items-center justify-center text-gray-400 text-sm">
              {isRTL ? 'لا توجد صورة' : 'Aucune image'}
            </div>
          )}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-600 mb-1">{isRTL ? 'إضافة رابط صورة' : 'Ajouter URL Image'}</label>
        <input
          type="url"
          onBlur={e => {
            const value = e.currentTarget.value.trim();
            if (value) {
              setFormData(p => ({ ...p, images: [...p.images.filter(Boolean), value] }));
              e.currentTarget.value = '';
            }
          }}
          className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:border-pink-400 text-sm"
          placeholder="https://..."
          dir="ltr"
        />
      </div>

      <div className="flex items-center gap-2">
        <input
          type="checkbox"
          id="featured"
          checked={formData.featured}
          onChange={e => setFormData(p => ({ ...p, featured: e.target.checked }))}
          className="w-4 h-4 accent-pink-500"
        />
        <label htmlFor="featured" className="text-sm font-medium text-gray-600">
          {isRTL ? 'منتج مميز (يظهر في الصفحة الرئيسية)' : 'Produit vedette (affiché en page d\'accueil)'}
        </label>
      </div>
    </div>
  );

  return (
    <div className="space-y-6" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-gray-800">
            {isRTL ? 'إدارة المنتجات' : 'Gestion des produits'}
          </h2>
          <p className="text-gray-500 text-sm mt-1">
            {products.length} {isRTL ? 'منتج' : 'produits'}
          </p>
        </div>
        <button
          onClick={openAdd}
          className="flex items-center gap-2 bg-gradient-to-r from-pink-500 to-purple-600 text-white px-5 py-3 rounded-xl font-bold hover:shadow-lg transition-all"
        >
          <Plus size={18} />
          {isRTL ? 'إضافة منتج' : 'Ajouter'}
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search size={16} className={`absolute top-1/2 -translate-y-1/2 ${isRTL ? 'right-3' : 'left-3'} text-gray-400`} />
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder={isRTL ? 'بحث عن منتج...' : 'Rechercher un produit...'}
          className={`w-full ${isRTL ? 'pr-9 pl-3' : 'pl-9 pr-3'} py-3 border border-gray-200 rounded-2xl focus:outline-none focus:border-pink-400 bg-white`}
        />
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(product => {
          const discount = product.discountPrice
            ? Math.round(((product.price - product.discountPrice) / product.price) * 100)
            : 0;
          return (
            <div key={product.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden hover:shadow-md transition-shadow">
              {/* Image */}
              <div className={`h-40 bg-gradient-to-br ${product.bgColor || 'from-pink-50 to-purple-50'} relative`}>
                {product.images[0] ? (
                  <img src={product.images[0]} alt="" className="w-full h-full object-cover" onError={e => (e.target as HTMLImageElement).style.display = 'none'} />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-5xl opacity-30">🛍️</div>
                )}
                {product.badge && (
                  <span className="absolute top-2 right-2 bg-pink-500 text-white text-xs px-2 py-0.5 rounded-full font-medium">
                    {product.badge}
                  </span>
                )}
                {discount > 0 && (
                  <span className="absolute top-2 left-2 bg-red-500 text-white text-xs px-2 py-0.5 rounded-full font-medium">
                    -{discount}%
                  </span>
                )}
              </div>

              {/* Content */}
              <div className="p-4">
                <h3 className="font-bold text-gray-800 text-sm mb-1 truncate">
                  {isRTL ? product.nameAr : product.nameFr}
                </h3>
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <span className="text-pink-600 font-black">
                      {(product.discountPrice || product.price).toLocaleString()} دج
                    </span>
                    {product.discountPrice && (
                      <span className="text-gray-400 text-xs line-through mr-1">{product.price.toLocaleString()}</span>
                    )}
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    product.stock === 0 ? 'bg-red-100 text-red-600' :
                    product.stock <= 5 ? 'bg-orange-100 text-orange-600' :
                    'bg-green-100 text-green-600'
                  }`}>
                    {product.stock === 0 ? (isRTL ? 'نفذ' : 'Épuisé') : `${product.stock} ${isRTL ? 'متبقي' : 'restants'}`}
                  </span>
                </div>

                {/* Quick Stock Edit */}
                <div className="flex items-center gap-2 mb-3">
                  <label className="text-xs text-gray-500 shrink-0">{isRTL ? 'المخزون:' : 'Stock:'}</label>
                  <input
                    type="number"
                    value={product.stock}
                    onChange={e => updateProduct(product.id, { stock: parseInt(e.target.value) || 0 })}
                    className="w-20 px-2 py-1 border border-gray-200 rounded-lg text-xs text-center focus:outline-none focus:border-pink-400"
                  />
                  <label className="text-xs text-gray-500 shrink-0">{isRTL ? 'السعر:' : 'Prix:'}</label>
                  <input
                    type="number"
                    value={product.price}
                    onChange={e => updateProduct(product.id, { price: parseFloat(e.target.value) || 0 })}
                    className="w-24 px-2 py-1 border border-gray-200 rounded-lg text-xs text-center focus:outline-none focus:border-pink-400"
                  />
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <button
                    onClick={() => openEdit(product)}
                    className="flex-1 flex items-center justify-center gap-1 py-2 bg-blue-50 text-blue-600 rounded-xl text-xs font-medium hover:bg-blue-100 transition-colors"
                  >
                    <Edit2 size={14} />
                    {isRTL ? 'تعديل' : 'Modifier'}
                  </button>
                  <button
                    onClick={() => setDeleteConfirm(product.id)}
                    className="flex items-center justify-center gap-1 px-3 py-2 bg-red-50 text-red-500 rounded-xl text-xs font-medium hover:bg-red-100 transition-colors"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Edit/Add Modal */}
      {(editingProduct || showAddModal) && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => { setEditingProduct(null); setShowAddModal(false); }}>
          <div
            className="bg-white rounded-3xl p-6 w-full max-w-2xl shadow-2xl max-h-[90vh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            dir={isRTL ? 'rtl' : 'ltr'}
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-black text-gray-800">
                {editingProduct ? (isRTL ? 'تعديل المنتج' : 'Modifier le produit') : (isRTL ? 'إضافة منتج جديد' : 'Ajouter un produit')}
              </h3>
              <button onClick={() => { setEditingProduct(null); setShowAddModal(false); }} className="p-2 hover:bg-gray-100 rounded-xl">
                <X size={20} />
              </button>
            </div>
            <ProductForm />
            <div className="flex gap-3 mt-6">
              <button
                onClick={handleSave}
                className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-pink-500 to-purple-600 text-white py-3 rounded-xl font-bold hover:shadow-lg transition-all"
              >
                <Save size={18} />
                {isRTL ? 'حفظ' : 'Enregistrer'}
              </button>
              <button
                onClick={() => { setEditingProduct(null); setShowAddModal(false); }}
                className="px-6 py-3 border border-gray-200 text-gray-700 rounded-xl font-medium hover:bg-gray-50 transition-colors"
              >
                {isRTL ? 'إلغاء' : 'Annuler'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirm */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl" onClick={e => e.stopPropagation()} dir={isRTL ? 'rtl' : 'ltr'}>
            <div className="text-center mb-6">
              <div className="text-5xl mb-3">⚠️</div>
              <h3 className="text-xl font-black text-gray-800 mb-2">
                {isRTL ? 'حذف المنتج؟' : 'Supprimer le produit?'}
              </h3>
              <p className="text-gray-500 text-sm">
                {isRTL ? 'هذا الإجراء لا يمكن التراجع عنه' : 'Cette action est irréversible'}
              </p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => { deleteProduct(deleteConfirm); setDeleteConfirm(null); }}
                className="flex-1 py-3 bg-red-500 text-white rounded-xl font-bold hover:bg-red-600 transition-colors"
              >
                {isRTL ? 'حذف' : 'Supprimer'}
              </button>
              <button
                onClick={() => setDeleteConfirm(null)}
                className="flex-1 py-3 border border-gray-200 text-gray-700 rounded-xl font-medium hover:bg-gray-50 transition-colors"
              >
                {isRTL ? 'إلغاء' : 'Annuler'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminProducts;
