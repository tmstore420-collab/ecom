import React from 'react';
import { TrendingUp, ShoppingCart, Package, Truck, AlertCircle, CheckCircle2, Clock, XCircle } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { useTranslation } from '../../hooks/useTranslation';

const AdminDashboard: React.FC = () => {
  const { orders, products } = useStore();
  const { isRTL } = useTranslation();

  const totalRevenue = orders
    .filter(o => o.status !== 'cancelled')
    .reduce((sum, o) => sum + o.totalPrice, 0);

  const statusCounts = {
    pending: orders.filter(o => o.status === 'pending').length,
    confirmed: orders.filter(o => o.status === 'confirmed').length,
    shipped: orders.filter(o => o.status === 'shipped').length,
    delivered: orders.filter(o => o.status === 'delivered').length,
    cancelled: orders.filter(o => o.status === 'cancelled').length,
  };

  const stats = [
    {
      label: isRTL ? 'إجمالي الطلبات' : 'Total commandes',
      value: orders.length,
      icon: <ShoppingCart size={24} className="text-blue-600" />,
      bg: 'bg-blue-50',
      border: 'border-blue-100',
      change: '+12%',
    },
    {
      label: isRTL ? 'الإيرادات الكلية' : 'Revenus totaux',
      value: `${totalRevenue.toLocaleString()} دج`,
      icon: <TrendingUp size={24} className="text-green-600" />,
      bg: 'bg-green-50',
      border: 'border-green-100',
      change: '+8%',
    },
    {
      label: isRTL ? 'المنتجات' : 'Produits',
      value: products.length,
      icon: <Package size={24} className="text-purple-600" />,
      bg: 'bg-purple-50',
      border: 'border-purple-100',
      change: `${products.filter(p => p.stock === 0).length} نفذ`,
    },
    {
      label: isRTL ? 'قيد التوصيل' : 'En livraison',
      value: statusCounts.shipped,
      icon: <Truck size={24} className="text-orange-600" />,
      bg: 'bg-orange-50',
      border: 'border-orange-100',
      change: isRTL ? 'اليوم' : "Aujourd'hui",
    },
  ];

  const statusCards = [
    { key: 'pending', label: isRTL ? 'قيد الانتظار' : 'En attente', count: statusCounts.pending, icon: <Clock size={20} />, color: 'text-yellow-600 bg-yellow-50 border-yellow-200' },
    { key: 'confirmed', label: isRTL ? 'مؤكدة' : 'Confirmées', count: statusCounts.confirmed, icon: <CheckCircle2 size={20} />, color: 'text-blue-600 bg-blue-50 border-blue-200' },
    { key: 'shipped', label: isRTL ? 'مشحونة' : 'Expédiées', count: statusCounts.shipped, icon: <Truck size={20} />, color: 'text-purple-600 bg-purple-50 border-purple-200' },
    { key: 'delivered', label: isRTL ? 'تم التوصيل' : 'Livrées', count: statusCounts.delivered, icon: <CheckCircle2 size={20} />, color: 'text-green-600 bg-green-50 border-green-200' },
    { key: 'cancelled', label: isRTL ? 'ملغاة' : 'Annulées', count: statusCounts.cancelled, icon: <XCircle size={20} />, color: 'text-red-600 bg-red-50 border-red-200' },
  ];

  const recentOrders = [...orders].slice(0, 5);
  const lowStockProducts = products.filter(p => p.stock <= 5 && p.stock > 0);

  return (
    <div className="space-y-6" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <div key={i} className={`${stat.bg} ${stat.border} border rounded-2xl p-5`}>
            <div className="flex items-start justify-between mb-3">
              <div className={`w-12 h-12 ${stat.bg} rounded-xl flex items-center justify-center shadow-sm`}>
                {stat.icon}
              </div>
              <span className="text-xs text-green-600 font-bold bg-green-100 px-2 py-0.5 rounded-full">
                {stat.change}
              </span>
            </div>
            <div className="text-2xl font-black text-gray-800 mb-1">{stat.value}</div>
            <div className="text-sm text-gray-500">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Status Overview */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <h3 className="font-black text-gray-800 mb-4 text-lg">
          {isRTL ? 'حالات الطلبات' : 'Statuts des commandes'}
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {statusCards.map(s => (
            <div key={s.key} className={`${s.color} border rounded-xl p-4 text-center`}>
              <div className="flex justify-center mb-2">{s.icon}</div>
              <div className="text-2xl font-black">{s.count}</div>
              <div className="text-xs font-medium mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Recent Orders */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <h3 className="font-black text-gray-800 mb-4 text-lg">
            {isRTL ? 'أحدث الطلبات' : 'Commandes récentes'}
          </h3>
          {recentOrders.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <ShoppingCart size={40} className="mx-auto mb-2 opacity-30" />
              <p>{isRTL ? 'لا توجد طلبات بعد' : 'Aucune commande pour le moment'}</p>
            </div>
          ) : (
            <div className="space-y-3">
              {recentOrders.map(order => (
                <div key={order.id} className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-100 to-purple-100 flex items-center justify-center text-sm font-bold text-pink-600">
                    #{order.id.slice(-4)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-gray-800 text-sm truncate">{order.customerName}</div>
                    <div className="text-xs text-gray-400">{order.wilayaName}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-gray-800 text-sm">{order.totalPrice.toLocaleString()} دج</div>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                      order.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                      order.status === 'delivered' ? 'bg-green-100 text-green-700' :
                      order.status === 'cancelled' ? 'bg-red-100 text-red-700' :
                      'bg-blue-100 text-blue-700'
                    }`}>
                      {order.status === 'pending' ? (isRTL ? 'انتظار' : 'Attente') :
                       order.status === 'confirmed' ? (isRTL ? 'مؤكد' : 'Confirmé') :
                       order.status === 'shipped' ? (isRTL ? 'شحن' : 'Expédié') :
                       order.status === 'delivered' ? (isRTL ? 'تسليم' : 'Livré') :
                       (isRTL ? 'ملغي' : 'Annulé')}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Low Stock Alert */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <h3 className="font-black text-gray-800 mb-4 text-lg flex items-center gap-2">
            <AlertCircle size={20} className="text-orange-500" />
            {isRTL ? 'تنبيه المخزون' : 'Alerte stock'}
          </h3>
          {lowStockProducts.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <CheckCircle2 size={40} className="mx-auto mb-2 opacity-30 text-green-400" />
              <p className="text-green-600 font-medium">{isRTL ? 'المخزون ممتاز!' : 'Stock excellent!'}</p>
            </div>
          ) : (
            <div className="space-y-3">
              {lowStockProducts.map(p => (
                <div key={p.id} className="flex items-center justify-between p-3 rounded-xl bg-orange-50 border border-orange-100">
                  <div>
                    <div className="font-medium text-gray-800 text-sm">{isRTL ? p.nameAr : p.nameFr}</div>
                    <div className="text-xs text-orange-600">
                      {isRTL ? `${p.stock} متبقي فقط` : `${p.stock} restants`}
                    </div>
                  </div>
                  <div className="w-16 bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-orange-500 h-2 rounded-full transition-all"
                      style={{ width: `${Math.min(100, (p.stock / 20) * 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="bg-gradient-to-r from-pink-500 to-purple-600 rounded-2xl p-6 text-white">
        <h3 className="font-black text-xl mb-4">
          {isRTL ? '📊 ملخص المتجر' : '📊 Résumé du magasin'}
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { label: isRTL ? 'معدل التحويل' : 'Taux conversion', value: '68%' },
            { label: isRTL ? 'متوسط الطلب' : 'Panier moyen', value: orders.length ? `${Math.round(totalRevenue / orders.length).toLocaleString()} دج` : '0 دج' },
            { label: isRTL ? 'أكثر ولاية' : 'Wilaya top', value: isRTL ? 'الجزائر' : 'Alger' },
            { label: isRTL ? 'شركة التوصيل' : 'Livreur top', value: 'Yalidine' },
          ].map((s, i) => (
            <div key={i} className="bg-white/20 rounded-xl p-4 text-center">
              <div className="text-2xl font-black">{s.value}</div>
              <div className="text-white/70 text-xs mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
