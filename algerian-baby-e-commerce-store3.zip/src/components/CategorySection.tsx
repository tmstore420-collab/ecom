import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from '../hooks/useTranslation';
import { useStore } from '../store/useStore';

const CategorySection: React.FC = () => {
  const { language, isRTL } = useTranslation();
  const { setSelectedCategory, products, categories } = useStore();

  return (
    <section className="py-16 bg-gradient-to-b from-white to-pink-50/30" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-black text-gray-800 mb-3">
            {language === 'ar' ? 'تسوق حسب الفئة' : 'Acheter par catégorie'}
          </h2>
          <p className="text-gray-500 text-lg">
            {language === 'ar' 
              ? 'اكتشف مجموعتنا الواسعة من منتجات الأطفال' 
              : 'Découvrez notre large gamme de produits bébé'}
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
          {categories.map((cat, index) => {
            const count = products.filter(p => p.category === cat.id).length;
            return (
              <Link
                key={cat.id}
                to="/products"
                onClick={() => setSelectedCategory(cat.id)}
                className="group cursor-pointer"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex flex-col items-center p-5 bg-white rounded-3xl shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border border-gray-100 group-hover:border-pink-200">
                  {/* Icon */}
                  <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${cat.color} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                    <span className="text-2xl">{cat.icon}</span>
                  </div>

                  {/* Label */}
                  <h3 className="font-bold text-gray-700 text-center text-sm leading-tight group-hover:text-pink-600 transition-colors">
                    {language === 'ar' ? cat.labelAr : cat.labelFr}
                  </h3>

                  {/* Count */}
                  <span className="text-xs text-gray-400 mt-1">
                    {count} {language === 'ar' ? 'منتج' : 'produits'}
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default CategorySection;
