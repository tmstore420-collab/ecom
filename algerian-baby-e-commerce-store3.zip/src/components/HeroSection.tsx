import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Star, Truck, Shield, Heart } from 'lucide-react';
import { useTranslation } from '../hooks/useTranslation';
import { useStore } from '../store/useStore';

const HeroSection: React.FC = () => {
  const { t, isRTL } = useTranslation();
  const { settings } = useStore();
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = settings.heroOffers?.length
    ? settings.heroOffers
    : [
        {
          id: 'default-offer',
          gradient: settings.heroGradient || 'from-pink-500 via-rose-400 to-purple-600',
          titleAr: settings.heroTitleAr || 'كل ما يحتاجه طفلك',
          titleFr: settings.heroTitleFr || 'Tout ce dont votre bébé a besoin',
          subtitleAr: settings.heroSubtitleAr || 'جودة عالية • أسعار مناسبة • توصيل لكل الجزائر',
          subtitleFr: settings.heroSubtitleFr || 'Haute qualité • Prix abordables • Livraison partout en Algérie',
          badgeAr: 'أفضل متجر للأطفال',
          badgeFr: 'Meilleure boutique bébé',
          emoji: '👶',
        },
      ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const slide = slides[currentSlide % slides.length];
  const heroImageWidth = settings.heroImageWidth || 320;
  const heroImageHeight = settings.heroImageHeight || 224;

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Animated Background */}
      <div className={`absolute inset-0 bg-gradient-to-br ${slide.gradient} transition-all duration-1000`} />
      {settings.heroBackgroundImageUrl && (
        <div
          className="absolute inset-0 bg-cover bg-center opacity-35 mix-blend-overlay"
          style={{ backgroundImage: `url(${settings.heroBackgroundImageUrl})` }}
        />
      )}
      
      {/* Pattern Overlay */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, white 1px, transparent 0)`,
          backgroundSize: '40px 40px',
        }} />
      </div>

      {/* Floating Elements */}
      <div className="absolute top-20 right-10 text-6xl animate-bounce opacity-20">👶</div>
      <div className="absolute bottom-20 left-10 text-5xl animate-pulse opacity-20">🌸</div>
      <div className="absolute top-1/2 right-1/4 text-4xl animate-spin opacity-10" style={{ animationDuration: '10s' }}>⭐</div>
      <div className="absolute top-1/3 left-1/4 text-5xl animate-bounce opacity-15" style={{ animationDelay: '1s' }}>🎀</div>

      {/* Decorative Circles */}
      <div className="absolute -top-20 -right-20 w-80 h-80 bg-white/10 rounded-full blur-3xl" />
      <div className="absolute -bottom-20 -left-20 w-96 h-96 bg-white/10 rounded-full blur-3xl" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-white/5 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-24 pt-32 md:pt-36">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div className={`text-white ${isRTL ? 'md:text-right' : 'md:text-left'} text-center`}>
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-medium mb-6 border border-white/30">
              <span>{slide.emoji} {isRTL ? slide.badgeAr : slide.badgeFr}</span>
            </div>

            {/* Title */}
            <h1 className="text-4xl md:text-6xl font-black mb-4 leading-tight">
              {isRTL ? slide.titleAr : slide.titleFr}
            </h1>

            {/* Subtitle */}
            <p className="text-lg md:text-xl text-white/85 mb-8 leading-relaxed">
              {isRTL ? slide.subtitleAr : slide.subtitleFr}
            </p>

            {/* Stats */}
            <div className="flex items-center justify-center md:justify-start gap-6 mb-10">
              {[
                { num: '500+', label: isRTL ? 'منتج' : 'Produits' },
                { num: '58', label: isRTL ? 'ولاية' : 'Wilayas' },
                { num: '1000+', label: isRTL ? 'عميل' : 'Clients' },
              ].map((stat, i) => (
                <div key={i} className="text-center">
                  <div className="text-2xl font-black">{stat.num}</div>
                  <div className="text-white/70 text-sm">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* CTAs */}
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-4">
              <Link
                to="/products"
                className="flex items-center gap-2 bg-white text-pink-600 px-8 py-4 rounded-2xl font-bold hover:shadow-xl hover:scale-105 transition-all duration-200 text-lg"
              >
                <span>{t('shopNow')}</span>
                {isRTL ? <ArrowLeft size={20} /> : <ArrowRight size={20} />}
              </Link>
              <Link
                to="/products"
                className="flex items-center gap-2 bg-white/20 backdrop-blur-sm text-white border-2 border-white/40 px-8 py-4 rounded-2xl font-bold hover:bg-white/30 transition-all duration-200 text-lg"
              >
                {t('discoverProducts')}
              </Link>
            </div>
          </div>

          {/* Right Visual */}
          <div className="flex justify-center">
            <div className="relative">
              {/* Main Card */}
              <div className="bg-white/20 backdrop-blur-md rounded-3xl overflow-hidden border border-white/30 shadow-2xl text-center">
                <img
                  src={settings.heroImageUrl || '/hero-baby.jpg'}
                  alt="Baby care products"
                  className="object-cover max-w-[88vw]"
                  style={{ width: heroImageWidth, height: heroImageHeight }}
                  onError={e => { (e.target as HTMLImageElement).style.display='none'; }}
                />
                <div className="p-6">
                <div className="text-5xl mb-2">{slide.emoji}</div>
                <div className="text-white font-bold text-xl mb-2">
                  {isRTL ? settings.storeNameAr : settings.storeNameFr}
                </div>
                <div className="flex items-center justify-center gap-1 text-yellow-300">
                  {[...Array(5)].map((_, i) => <Star key={i} size={16} fill="currentColor" />)}
                  <span className="text-white/80 text-sm mr-2">4.9 (500+ تقييم)</span>
                </div>
                </div>
              </div>

              {/* Floating Cards */}
              <div className="absolute -top-4 -left-8 bg-white rounded-2xl p-3 shadow-xl flex items-center gap-2">
                <div className="w-8 h-8 bg-green-100 rounded-xl flex items-center justify-center">
                  <Truck size={16} className="text-green-600" />
                </div>
                <div>
                  <div className="text-xs font-bold text-gray-800">{isRTL ? 'توصيل سريع' : 'Livraison rapide'}</div>
                  <div className="text-xs text-gray-500">48-72h</div>
                </div>
              </div>

              <div className="absolute -bottom-4 -right-8 bg-white rounded-2xl p-3 shadow-xl flex items-center gap-2">
                <div className="w-8 h-8 bg-pink-100 rounded-xl flex items-center justify-center">
                  <Shield size={16} className="text-pink-600" />
                </div>
                <div>
                  <div className="text-xs font-bold text-gray-800">{isRTL ? 'ضمان الجودة' : 'Garantie qualité'}</div>
                  <div className="text-xs text-gray-500">100%</div>
                </div>
              </div>

              <div className="absolute top-1/2 -right-12 bg-white rounded-2xl p-3 shadow-xl flex items-center gap-2">
                <div className="w-8 h-8 bg-red-100 rounded-xl flex items-center justify-center">
                  <Heart size={16} className="text-red-500" />
                </div>
                <div>
                  <div className="text-xs font-bold text-gray-800">COD</div>
                  <div className="text-xs text-gray-500">{isRTL ? 'دفع عند الاستلام' : 'Paiement à livraison'}</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Slide Indicators */}
        <div className="flex justify-center gap-2 mt-12">
          {slides.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentSlide(i)}
              className={`h-2 rounded-full transition-all duration-300 ${
                i === currentSlide ? 'w-8 bg-white' : 'w-2 bg-white/40'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Bottom Wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 80" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 80L60 68.7C120 57.3 240 34.7 360 29.3C480 24 600 36 720 42.7C840 49.3 960 50.7 1080 46.7C1200 42.7 1320 33.3 1380 28.7L1440 24V80H1380C1320 80 1200 80 1080 80C960 80 840 80 720 80C600 80 480 80 360 80C240 80 120 80 60 80H0Z" fill="white"/>
        </svg>
      </div>
    </section>
  );
};

export default HeroSection;
