import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Search, Menu, X, Globe, ChevronDown } from 'lucide-react';
import { useStore } from '../store/useStore';
import { useTranslation } from '../hooks/useTranslation';

const Navbar: React.FC = () => {
  const { t, language, isRTL } = useTranslation();
  const { setLanguage, settings, categories, searchQuery, setSearchQuery, setSelectedCategory } = useStore();
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [catOpen, setCatOpen] = useState(false);
  const [logoClicks, setLogoClicks] = useState(0);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate('/products');
      setSearchOpen(false);
    }
  };

  const handleCategorySelect = (catId: string) => {
    setSelectedCategory(catId as any);
    navigate('/products');
    setCatOpen(false);
    setMenuOpen(false);
  };

  const handleHiddenAdminClick = (e: React.MouseEvent) => {
    e.preventDefault();
    const nextCount = logoClicks + 1;
    setLogoClicks(nextCount);
    if (nextCount >= 5) {
      setLogoClicks(0);
      navigate('/admin');
    }
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-white/90 backdrop-blur-sm'
    }`} dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <div className="flex items-center gap-2 group">
            <Link to="/" className="w-10 h-10 rounded-2xl bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
              <span className="text-white text-lg font-bold">B</span>
            </Link>
            <div>
              <button
                type="button"
                onClick={handleHiddenAdminClick}
                className="font-bold text-lg bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent select-none"
                title="Baby-care DZ"
              >
                {settings.storeNameAr}
              </button>
              <div className="text-xs text-gray-400 leading-none">الجزائر | Algérie</div>
            </div>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-6">
            <Link to="/" className={`text-gray-700 hover:text-pink-600 font-medium transition-colors ${location.pathname === '/' ? 'text-pink-600' : ''}`}>
              {t('home')}
            </Link>
            
            {/* Categories Dropdown */}
            <div className="relative">
              <button
                onClick={() => setCatOpen(!catOpen)}
                className="flex items-center gap-1 text-gray-700 hover:text-pink-600 font-medium transition-colors"
              >
                {t('categories')}
                <ChevronDown size={16} className={`transition-transform ${catOpen ? 'rotate-180' : ''}`} />
              </button>
              {catOpen && (
                <div className={`absolute top-full mt-2 w-56 bg-white rounded-2xl shadow-xl border border-pink-100 py-2 z-50 ${isRTL ? 'right-0' : 'left-0'}`}>
                  <button
                    onClick={() => handleCategorySelect('all')}
                    className="w-full text-right px-4 py-2 text-gray-700 hover:bg-pink-50 hover:text-pink-600 transition-colors text-sm"
                  >
                    {t('allCategories')}
                  </button>
                  {categories.map(cat => (
                    <button
                      key={cat.id}
                      onClick={() => handleCategorySelect(cat.id)}
                      className="w-full text-right px-4 py-2 text-gray-700 hover:bg-pink-50 hover:text-pink-600 transition-colors text-sm flex items-center gap-2"
                    >
                      <span>{cat.icon}</span>
                      <span>{language === 'ar' ? cat.labelAr : cat.labelFr}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            <Link to="/products" className={`text-gray-700 hover:text-pink-600 font-medium transition-colors ${location.pathname === '/products' ? 'text-pink-600' : ''}`}>
              {t('products')}
            </Link>
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-2">
            {/* Search */}
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className="p-2 rounded-xl text-gray-600 hover:text-pink-600 hover:bg-pink-50 transition-all"
            >
              <Search size={20} />
            </button>

            {/* Language Toggle */}
            <button
              onClick={() => setLanguage(language === 'ar' ? 'fr' : 'ar')}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl border border-pink-200 text-pink-600 hover:bg-pink-50 transition-all text-sm font-medium"
            >
              <Globe size={14} />
              <span>{language === 'ar' ? 'FR' : 'عر'}</span>
            </button>

            {/* Mobile Menu */}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="md:hidden p-2 rounded-xl text-gray-600 hover:bg-pink-50 transition-all"
            >
              {menuOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>

        {/* Search Bar */}
        {searchOpen && (
          <div className="pb-4">
            <form onSubmit={handleSearch} className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t('searchPlaceholder')}
                className="w-full pl-4 pr-12 py-3 rounded-2xl border-2 border-pink-200 focus:border-pink-400 focus:outline-none text-gray-800 bg-white"
                autoFocus
                dir={isRTL ? 'rtl' : 'ltr'}
              />
              <button type="submit" className={`absolute ${isRTL ? 'left-3' : 'right-3'} top-1/2 -translate-y-1/2 p-1 text-pink-500`}>
                <Search size={20} />
              </button>
            </form>
          </div>
        )}

        {/* Mobile Menu */}
        {menuOpen && (
          <div className="md:hidden pb-4 border-t border-pink-100 pt-4 space-y-2">
            <Link to="/" onClick={() => setMenuOpen(false)} className="block px-4 py-2 rounded-xl text-gray-700 hover:bg-pink-50 hover:text-pink-600 font-medium">
              {t('home')}
            </Link>
            <Link to="/products" onClick={() => setMenuOpen(false)} className="block px-4 py-2 rounded-xl text-gray-700 hover:bg-pink-50 hover:text-pink-600 font-medium">
              {t('products')}
            </Link>
            <div className="px-4 py-2">
              <p className="text-xs text-gray-400 mb-2 font-medium">{t('categories')}</p>
              <div className="grid grid-cols-2 gap-2">
                {categories.map(cat => (
                  <button
                    key={cat.id}
                    onClick={() => handleCategorySelect(cat.id)}
                    className="flex items-center gap-2 px-3 py-2 rounded-xl bg-pink-50 text-pink-700 text-sm hover:bg-pink-100 transition-colors"
                  >
                    <span>{cat.icon}</span>
                    <span className="truncate">{language === 'ar' ? cat.labelAr : cat.labelFr}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Click outside to close */}
      {catOpen && <div className="fixed inset-0 z-40" onClick={() => setCatOpen(false)} />}
    </nav>
  );
};

export default Navbar;
