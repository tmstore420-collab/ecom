import React, { useState } from 'react';
import { CheckCircle, Loader, MapPin, Phone, User, Package, Truck } from 'lucide-react';
import { useStore } from '../store/useStore';
import { useTranslation } from '../hooks/useTranslation';
import { WILAYAS, COMMUNES } from '../data/algeria';
import { Product } from '../data/products';
import { Order } from '../store/useStore';

interface CheckoutFormProps {
  product: Product;
  selectedVariations: Record<string, string>;
  quantity: number;
  onSuccess?: (orderId: string) => void;
}

const CheckoutForm: React.FC<CheckoutFormProps> = ({ product, selectedVariations, quantity, onSuccess }) => {
  const { t, language, isRTL } = useTranslation();
  const { deliveryCompanies, addOrder, settings } = useStore();

  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    wilayaId: '',
    commune: '',
    address: '',
    deliveryType: 'home' as 'home' | 'desk',
    deliveryCompanyId: '',
    notes: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [orderId, setOrderId] = useState('');

  const enabledCompanies = deliveryCompanies.filter(c => c.enabled);
  const communes = formData.wilayaId ? COMMUNES[parseInt(formData.wilayaId)] || [] : [];

  const getShippingFee = (): number => {
    if (!formData.wilayaId || !formData.deliveryCompanyId) return 0;
    const company = enabledCompanies.find(c => c.id === formData.deliveryCompanyId);
    if (!company) return 0;
    const wilayaFees = company.fees[parseInt(formData.wilayaId)];
    if (!wilayaFees) return 0;
    return formData.deliveryType === 'home' ? wilayaFees.home : wilayaFees.desk;
  };

  const productPrice = (product.discountPrice || product.price) * quantity;
  const shippingFee = getShippingFee();
  const total = productPrice + shippingFee;

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};
    if (!formData.fullName.trim()) newErrors.fullName = t('required');
    if (!formData.phone.trim()) newErrors.phone = t('required');
    else if (!/^(0[567]\d{8}|0[1234]\d{7})$/.test(formData.phone.replace(/\s/g, ''))) {
      newErrors.phone = t('invalidPhone');
    }
    if (!formData.wilayaId) newErrors.wilayaId = t('required');
    if (!formData.commune) newErrors.commune = t('required');
    if (!formData.address.trim()) newErrors.address = t('required');
    if (!formData.deliveryCompanyId) newErrors.deliveryCompanyId = t('required');
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    await new Promise(r => setTimeout(r, 1500));

    const wilaya = WILAYAS.find(w => w.id === parseInt(formData.wilayaId));
    const company = enabledCompanies.find(c => c.id === formData.deliveryCompanyId);
    const newOrderId = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`;

    const order: Order = {
      id: newOrderId,
      productId: product.id,
      productNameAr: product.nameAr,
      productNameFr: product.nameFr,
      customerName: formData.fullName,
      phone: formData.phone,
      wilayaId: parseInt(formData.wilayaId),
      wilayaName: wilaya ? (language === 'ar' ? wilaya.nameAr : wilaya.nameFr) : '',
      commune: formData.commune,
      address: formData.address,
      deliveryType: formData.deliveryType,
      deliveryCompany: company?.name || '',
      selectedVariations,
      quantity,
      unitPrice: product.discountPrice || product.price,
      shippingFee,
      totalPrice: total,
      status: 'pending',
      createdAt: new Date().toISOString(),
      notes: formData.notes,
    };

    addOrder(order);
    setOrderId(newOrderId);
    setLoading(false);
    setSuccess(true);
    onSuccess?.(newOrderId);

    // Facebook Pixel Event
    if (settings.facebookPixelId && typeof window !== 'undefined' && (window as any).fbq) {
      (window as any).fbq('track', 'Purchase', {
        value: total,
        currency: 'DZD',
        content_ids: [product.id],
        content_name: product.nameAr,
      });
    }
  };

  if (success) {
    return (
      <div className="text-center py-12 px-6" dir={isRTL ? 'rtl' : 'ltr'}>
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle size={40} className="text-green-500" />
        </div>
        <h2 className="text-2xl font-black text-gray-800 mb-3">{t('orderSuccess')}</h2>
        <p className="text-gray-500 mb-6">{t('orderSuccessDesc')}</p>
        <div className="bg-gradient-to-r from-pink-50 to-purple-50 rounded-2xl p-6 inline-block mb-8">
          <p className="text-sm text-gray-500 mb-1">{t('orderNumber')}</p>
          <p className="text-xl font-black text-pink-600">{orderId}</p>
        </div>
        <div className="space-y-3 text-sm text-gray-600">
          <p>📦 {isRTL ? 'سيتم التواصل معك لتأكيد الطلب' : 'Nous vous contacterons pour confirmer'}</p>
          <p>🚚 {isRTL ? 'التوصيل خلال 48-72 ساعة' : 'Livraison en 48-72h'}</p>
          <p>💰 {isRTL ? 'الدفع عند الاستلام' : 'Paiement à la livraison'}</p>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="space-y-6 bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
      {/* Section: Personal Info */}
      <div>
        <h3 className="flex items-center gap-2 font-bold text-gray-700 mb-4 text-lg">
          <div className="w-7 h-7 bg-pink-100 rounded-lg flex items-center justify-center">
            <User size={14} className="text-pink-600" />
          </div>
          {isRTL ? 'المعلومات الشخصية' : 'Informations personnelles'}
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">{t('fullName')} *</label>
            <input
              type="text"
              value={formData.fullName}
              onChange={e => setFormData(p => ({ ...p, fullName: e.target.value }))}
              className={`w-full px-4 py-3 rounded-xl border-2 ${errors.fullName ? 'border-red-300 bg-red-50' : 'border-gray-200 focus:border-pink-400'} focus:outline-none transition-colors`}
              placeholder={isRTL ? 'الاسم الكامل' : 'Nom complet'}
            />
            {errors.fullName && <p className="text-red-500 text-xs mt-1">{errors.fullName}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">
              <Phone size={14} className="inline mr-1" />
              {t('phoneNumber')} *
            </label>
            <input
              type="tel"
              value={formData.phone}
              onChange={e => setFormData(p => ({ ...p, phone: e.target.value }))}
              className={`w-full px-4 py-3 rounded-xl border-2 ${errors.phone ? 'border-red-300 bg-red-50' : 'border-gray-200 focus:border-pink-400'} focus:outline-none transition-colors`}
              placeholder="0770000000"
              dir="ltr"
            />
            {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
          </div>
        </div>
      </div>

      {/* Section: Address */}
      <div>
        <h3 className="flex items-center gap-2 font-bold text-gray-700 mb-4 text-lg">
          <div className="w-7 h-7 bg-purple-100 rounded-lg flex items-center justify-center">
            <MapPin size={14} className="text-purple-600" />
          </div>
          {isRTL ? 'عنوان التوصيل' : 'Adresse de livraison'}
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">{t('wilaya')} *</label>
            <select
              value={formData.wilayaId}
              onChange={e => setFormData(p => ({ ...p, wilayaId: e.target.value, commune: '' }))}
              className={`w-full px-4 py-3 rounded-xl border-2 ${errors.wilayaId ? 'border-red-300 bg-red-50' : 'border-gray-200 focus:border-pink-400'} focus:outline-none transition-colors bg-white`}
            >
              <option value="">{t('selectWilaya')}</option>
              {WILAYAS.map(w => (
                <option key={w.id} value={w.id}>
                  {w.id.toString().padStart(2, '0')} - {language === 'ar' ? w.nameAr : w.nameFr}
                </option>
              ))}
            </select>
            {errors.wilayaId && <p className="text-red-500 text-xs mt-1">{errors.wilayaId}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1.5">{t('commune')} *</label>
            <select
              key={formData.wilayaId || 'no-wilaya'}
              value={formData.commune}
              onChange={e => setFormData(p => ({ ...p, commune: e.target.value }))}
              disabled={!formData.wilayaId}
              className={`w-full px-4 py-3 rounded-xl border-2 ${errors.commune ? 'border-red-300 bg-red-50' : 'border-gray-200 focus:border-pink-400'} focus:outline-none transition-colors bg-white disabled:opacity-50`}
            >
              <option value="">{t('selectCommune')}</option>
              {communes.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
            {errors.commune && <p className="text-red-500 text-xs mt-1">{errors.commune}</p>}
          </div>
          <div className="sm:col-span-2">
            <label className="block text-sm font-medium text-gray-600 mb-1.5">{t('address')} *</label>
            <textarea
              value={formData.address}
              onChange={e => setFormData(p => ({ ...p, address: e.target.value }))}
              rows={2}
              className={`w-full px-4 py-3 rounded-xl border-2 ${errors.address ? 'border-red-300 bg-red-50' : 'border-gray-200 focus:border-pink-400'} focus:outline-none transition-colors resize-none`}
              placeholder={isRTL ? 'الحي، الشارع، رقم المبنى...' : 'Quartier, rue, numéro...'}
            />
            {errors.address && <p className="text-red-500 text-xs mt-1">{errors.address}</p>}
          </div>
        </div>
      </div>
      </div>

      <div className="space-y-6 bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
      {/* Section: Delivery */}
      <div>
        <h3 className="flex items-center gap-2 font-bold text-gray-700 mb-4 text-lg">
          <div className="w-7 h-7 bg-blue-100 rounded-lg flex items-center justify-center">
            <Truck size={14} className="text-blue-600" />
          </div>
          {isRTL ? 'خيارات التوصيل' : 'Options de livraison'}
        </h3>
        
        {/* Delivery Type */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          {(['home', 'desk'] as const).map(type => (
            <button
              key={type}
              type="button"
              onClick={() => setFormData(p => ({ ...p, deliveryType: type }))}
              className={`flex items-center justify-center gap-2 p-4 rounded-xl border-2 font-medium transition-all ${
                formData.deliveryType === type
                  ? 'border-pink-500 bg-pink-50 text-pink-700'
                  : 'border-gray-200 text-gray-600 hover:border-pink-200'
              }`}
            >
              <span>{type === 'home' ? '🏠' : '🏢'}</span>
              <span className="text-sm">{t(type === 'home' ? 'homeDelivery' : 'deskDelivery')}</span>
            </button>
          ))}
        </div>

        {/* Delivery Company */}
        <div>
          <label className="block text-sm font-medium text-gray-600 mb-2">{t('deliveryCompany')} *</label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {enabledCompanies.map(company => {
              const fee = formData.wilayaId 
                ? (formData.deliveryType === 'home' 
                    ? company.fees[parseInt(formData.wilayaId)]?.home 
                    : company.fees[parseInt(formData.wilayaId)]?.desk)
                : null;
              return (
                <button
                  key={company.id}
                  type="button"
                  onClick={() => setFormData(p => ({ ...p, deliveryCompanyId: company.id }))}
                  className={`flex items-center justify-between p-3 rounded-xl border-2 transition-all ${
                    formData.deliveryCompanyId === company.id
                      ? 'border-purple-500 bg-purple-50'
                      : 'border-gray-200 hover:border-purple-200'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{company.logo}</span>
                    <span className="font-medium text-sm text-gray-700">
                      {language === 'ar' ? company.nameAr : company.name}
                    </span>
                  </div>
                  {fee && (
                    <span className="text-purple-600 font-bold text-sm">{fee} {t('da')}</span>
                  )}
                </button>
              );
            })}
          </div>
          {errors.deliveryCompanyId && <p className="text-red-500 text-xs mt-1">{errors.deliveryCompanyId}</p>}
        </div>
      </div>

      {/* Notes */}
      <div>
        <label className="block text-sm font-medium text-gray-600 mb-1.5">
          <Package size={14} className="inline mr-1" />
          {t('notes')}
        </label>
        <textarea
          value={formData.notes}
          onChange={e => setFormData(p => ({ ...p, notes: e.target.value }))}
          rows={2}
          className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-pink-400 focus:outline-none transition-colors resize-none"
          placeholder={t('notesPlaceholder')}
        />
      </div>

      {/* Price Summary */}
      <div className="bg-gradient-to-br from-pink-50 to-purple-50 rounded-2xl p-5 border border-pink-100">
        <h4 className="font-bold text-gray-700 mb-4">
          {isRTL ? 'ملخص الطلب' : 'Récapitulatif'}
        </h4>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between items-center">
            <span className="text-gray-600">{isRTL ? 'سعر المنتج' : 'Prix produit'} × {quantity}</span>
            <span className="font-bold">{productPrice.toLocaleString()} {t('da')}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-600">{t('shippingFee')}</span>
            <span className={`font-bold ${shippingFee === 0 ? 'text-green-600' : ''}`}>
              {shippingFee === 0 ? (isRTL ? 'لم يُحدد' : 'Non défini') : `${shippingFee.toLocaleString()} ${t('da')}`}
            </span>
          </div>
          <div className="border-t border-pink-200 pt-2 flex justify-between items-center">
            <span className="font-bold text-gray-800 text-base">{t('orderTotal')}</span>
            <span className="font-black text-pink-600 text-xl">{total.toLocaleString()} {t('da')}</span>
          </div>
        </div>

        {/* COD Badge */}
        <div className="mt-4 flex items-center justify-center gap-2 bg-white/70 rounded-xl py-2 px-4">
          <span className="text-green-600 text-lg">💰</span>
          <span className="text-sm text-gray-600 font-medium">{t('codOnly')}</span>
        </div>
      </div>

      {/* Submit */}
      <button
        type="submit"
        disabled={loading}
        className="w-full bg-gradient-to-r from-pink-500 to-purple-600 text-white py-4 rounded-2xl font-black text-lg hover:shadow-xl hover:scale-[1.02] transition-all duration-200 disabled:opacity-60 disabled:scale-100 flex items-center justify-center gap-3"
      >
        {loading ? (
          <>
            <Loader size={20} className="animate-spin" />
            <span>{isRTL ? 'جاري الإرسال...' : 'Envoi en cours...'}</span>
          </>
        ) : (
          <>
            <span>🛒</span>
            <span>{t('confirmOrder')}</span>
          </>
        )}
      </button>
      </div>
    </form>
  );
};

export default CheckoutForm;
