import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, Tag, Star } from 'lucide-react';
import { Product } from '../data/products';
import { useTranslation } from '../hooks/useTranslation';
import { useStore } from '../store/useStore';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { t, language, isRTL } = useTranslation();
  const category = useStore((state) => state.categories.find(c => c.id === product.category));

  const name = language === 'ar' ? product.nameAr : product.nameFr;
  const discount = product.discountPrice 
    ? Math.round(((product.price - product.discountPrice) / product.price) * 100)
    : 0;
  const displayPrice = product.discountPrice || product.price;

  return (
    <Link to={`/product/${product.id}`} className="group block" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="bg-white rounded-3xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-gray-100">
        {/* Image Container */}
        <div className={`relative h-56 bg-gradient-to-br ${product.bgColor || 'from-pink-50 to-purple-50'} overflow-hidden`}>
          {product.images[0] ? (
            <img
              src={product.images[0]}
              alt={name}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = 'none';
              }}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-6xl">🛍️</div>
          )}
          
          {/* Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          {/* Badges */}
          <div className="absolute top-3 right-3 flex flex-col gap-2">
            {product.badge && (
              <span className="bg-gradient-to-r from-pink-500 to-purple-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg">
                {product.badge}
              </span>
            )}
            {discount > 0 && (
              <span className="bg-red-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg flex items-center gap-1">
                <Tag size={10} />
                -{discount}%
              </span>
            )}
          </div>

          {/* Stock Status */}
          {product.stock === 0 && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <span className="bg-white text-gray-800 font-bold px-4 py-2 rounded-xl text-sm">
                {t('outOfStock')}
              </span>
            </div>
          )}

          {/* Quick buy button */}
          <div className="absolute bottom-3 left-0 right-0 flex justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-4 group-hover:translate-y-0">
            <span className="bg-white/95 backdrop-blur-sm text-pink-600 font-bold px-6 py-2 rounded-full text-sm shadow-lg flex items-center gap-2">
              <ShoppingBag size={14} />
              {t('orderNow')}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          {/* Category */}
          <div className="text-xs text-pink-400 font-medium mb-1 uppercase tracking-wide">
            {category ? (language === 'ar' ? category.labelAr : category.labelFr) : product.category.replace('-', ' ')}
          </div>

          {/* Name */}
          <h3 className="font-bold text-gray-800 mb-2 line-clamp-2 group-hover:text-pink-600 transition-colors leading-tight">
            {name}
          </h3>

          {/* Variations Preview */}
          {product.variations.some(v => v.type === 'color') && (
            <div className="flex items-center gap-1 mb-3">
              {product.variations
                .filter(v => v.type === 'color')
                .slice(0, 4)
                .map(v => (
                  <div
                    key={v.id}
                    className="w-4 h-4 rounded-full border-2 border-white shadow-sm"
                    style={{ backgroundColor: v.value === 'multicolor' ? '#ff69b4' : v.value }}
                    title={language === 'ar' ? v.labelAr : v.labelFr}
                  />
                ))}
              {product.variations.filter(v => v.type === 'color').length > 4 && (
                <span className="text-xs text-gray-400">+{product.variations.filter(v => v.type === 'color').length - 4}</span>
              )}
            </div>
          )}

          {/* Rating */}
          <div className="flex items-center gap-1 mb-3">
            {[...Array(5)].map((_, i) => (
              <Star key={i} size={12} className={i < 4 ? 'text-yellow-400 fill-yellow-400' : 'text-gray-200 fill-gray-200'} />
            ))}
            <span className="text-xs text-gray-400 mr-1">(4.5)</span>
          </div>

          {/* Price */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xl font-black text-pink-600">
                {displayPrice.toLocaleString()} {t('da')}
              </span>
              {product.discountPrice && (
                <span className="text-sm text-gray-400 line-through">
                  {product.price.toLocaleString()}
                </span>
              )}
            </div>
          </div>

          {/* Stock indicator */}
          {product.stock > 0 && product.stock <= 10 && (
            <div className="mt-2 text-xs text-orange-500 font-medium">
              ⚠️ {isRTL ? `باقي ${product.stock} فقط` : `Seulement ${product.stock} restants`}
            </div>
          )}
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;
