import { useStore } from '../store/useStore';
import { translations, TranslationKey } from '../i18n/translations';

export const useTranslation = () => {
  const language = useStore((state) => state.language);
  
  const t = (key: TranslationKey): string => {
    return translations[language][key] || translations['ar'][key] || key;
  };
  
  const isRTL = language === 'ar';
  const dir = isRTL ? 'rtl' : 'ltr';
  const fontClass = isRTL ? 'font-cairo' : 'font-poppins';
  
  return { t, language, isRTL, dir, fontClass };
};
