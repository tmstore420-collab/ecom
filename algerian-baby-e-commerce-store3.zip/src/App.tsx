import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Navbar from './components/Navbar';
import WhatsAppButton from './components/WhatsAppButton';
import HomePage from './pages/HomePage';
import ProductsPage from './pages/ProductsPage';
import ProductDetailPage from './pages/ProductDetailPage';
import AdminPage from './pages/AdminPage';
import { useStore } from './store/useStore';

// Scroll to top on route change
const ScrollToTop: React.FC = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const FacebookPixel: React.FC = () => {
  const { pathname, search } = useLocation();
  const pixelId = useStore((state) => state.settings.facebookPixelId);

  useEffect(() => {
    if (!pixelId || typeof window === 'undefined') return;

    const w = window as any;
    if (!w.fbq) {
      w.fbq = function (...args: unknown[]) {
        w.fbq.callMethod ? w.fbq.callMethod(...args) : w.fbq.queue.push(args);
      };
      if (!w._fbq) w._fbq = w.fbq;
      w.fbq.push = w.fbq;
      w.fbq.loaded = true;
      w.fbq.version = '2.0';
      w.fbq.queue = [];

      const script = document.createElement('script');
      script.async = true;
      script.src = 'https://connect.facebook.net/en_US/fbevents.js';
      document.head.appendChild(script);
    }

    if (w.__babyCarePixelId !== pixelId) {
      w.fbq('init', pixelId);
      w.__babyCarePixelId = pixelId;
    }
  }, [pixelId]);

  useEffect(() => {
    const w = window as any;
    if (pixelId && w.fbq) {
      w.fbq('track', 'PageView');
    }
  }, [pixelId, pathname, search]);

  return null;
};

const AppLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { pathname } = useLocation();
  const isAdmin = pathname.startsWith('/admin');
  const { language } = useStore();

  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
    document.documentElement.style.fontFamily = language === 'ar' 
      ? "'Cairo', sans-serif" 
      : "'Poppins', sans-serif";
  }, [language]);

  return (
    <div className={language === 'ar' ? 'font-cairo' : 'font-poppins'}>
      {!isAdmin && <Navbar />}
      {children}
      {!isAdmin && <WhatsAppButton />}
    </div>
  );
};

const App: React.FC = () => {
  return (
    <BrowserRouter>
      <ScrollToTop />
      <FacebookPixel />
      <AppLayout>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/products" element={<ProductsPage />} />
          <Route path="/product/:id" element={<ProductDetailPage />} />
          <Route path="/admin" element={<AdminPage />} />
          <Route path="/admin/*" element={<AdminPage />} />
          <Route path="*" element={<HomePage />} />
        </Routes>
      </AppLayout>
      <Toaster
        position="top-center"
        toastOptions={{
          style: {
            background: '#fff',
            color: '#333',
            borderRadius: '16px',
            border: '1px solid #fce7f3',
            fontFamily: "'Cairo', sans-serif",
          },
          success: {
            iconTheme: { primary: '#ec4899', secondary: '#fff' },
          },
        }}
      />
    </BrowserRouter>
  );
};

export default App;
