import React, { useState } from 'react';
import { 
  LayoutDashboard, Package, ShoppingCart, Truck, Settings, LogOut, 
  ChevronRight, Menu, X, Eye
} from 'lucide-react';
import { useStore } from '../store/useStore';
import { useTranslation } from '../hooks/useTranslation';
import AdminLogin from '../components/admin/AdminLogin';
import AdminDashboard from '../components/admin/AdminDashboard';
import AdminOrders from '../components/admin/AdminOrders';
import AdminProducts from '../components/admin/AdminProducts';
import AdminDelivery from '../components/admin/AdminDelivery';
import AdminSettings from '../components/admin/AdminSettings';
import { Link } from 'react-router-dom';

type AdminTab = 'dashboard' | 'orders' | 'products' | 'delivery' | 'settings';

const AdminPage: React.FC = () => {
  const { adminAuthenticated, setAdminAuthenticated } = useStore();
  const { t, isRTL } = useTranslation();
  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (!adminAuthenticated) {
    return <AdminLogin />;
  }

  const navItems: { id: AdminTab; labelAr: string; labelFr: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', labelAr: 'لوحة التحكم', labelFr: 'Tableau de bord', icon: <LayoutDashboard size={20} /> },
    { id: 'orders', labelAr: 'الطلبات', labelFr: 'Commandes', icon: <ShoppingCart size={20} /> },
    { id: 'products', labelAr: 'المنتجات', labelFr: 'Produits', icon: <Package size={20} /> },
    { id: 'delivery', labelAr: 'التوصيل', labelFr: 'Livraison', icon: <Truck size={20} /> },
    { id: 'settings', labelAr: 'الإعدادات', labelFr: 'Paramètres', icon: <Settings size={20} /> },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <AdminDashboard />;
      case 'orders': return <AdminOrders />;
      case 'products': return <AdminProducts />;
      case 'delivery': return <AdminDelivery />;
      case 'settings': return <AdminSettings />;
    }
  };

  return (
    <div className={`min-h-screen bg-gray-100 flex ${isRTL ? 'font-cairo' : 'font-poppins'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 ${isRTL ? 'right-0' : 'left-0'} z-40 w-64 bg-gray-900 text-white
        transition-transform duration-300
        ${sidebarOpen ? 'translate-x-0' : isRTL ? 'translate-x-full' : '-translate-x-full'}
        md:translate-x-0 md:static md:flex md:flex-col
      `}>
        {/* Logo */}
        <div className="p-6 border-b border-gray-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center font-black text-lg">B</div>
            <div>
              <div className="font-black text-white">Baby-care DZ</div>
              <div className="text-xs text-gray-400">Admin Panel</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => { setActiveTab(item.id); setSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${
                activeTab === item.id
                  ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-lg'
                  : 'text-gray-400 hover:bg-gray-800 hover:text-white'
              }`}
            >
              {item.icon}
              <span>{isRTL ? item.labelAr : item.labelFr}</span>
              {activeTab === item.id && <ChevronRight size={16} className={`mr-auto ${isRTL ? 'rotate-180' : ''}`} />}
            </button>
          ))}
        </nav>

        {/* Bottom Actions */}
        <div className="p-4 border-t border-gray-800 space-y-2">
          <Link to="/" className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition-all font-medium">
            <Eye size={20} />
            <span>{isRTL ? 'عرض المتجر' : 'Voir le magasin'}</span>
          </Link>
          <button
            onClick={() => setAdminAuthenticated(false)}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-400 hover:bg-red-900/30 transition-all font-medium"
          >
            <LogOut size={20} />
            <span>{t('logout')}</span>
          </button>
        </div>
      </aside>

      {/* Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/60 z-30 md:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-screen min-w-0">
        {/* Top Bar */}
        <header className="bg-white border-b border-gray-200 px-4 sm:px-6 py-4 flex items-center justify-between sticky top-0 z-20 shadow-sm">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="md:hidden p-2 rounded-xl text-gray-600 hover:bg-gray-100"
            >
              {sidebarOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
            <h1 className="font-black text-gray-800 text-lg">
              {navItems.find(n => n.id === activeTab)?.[isRTL ? 'labelAr' : 'labelFr']}
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm text-gray-500">{isRTL ? 'مرحباً، الإدارة' : 'Bonjour, Admin'}</span>
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm">A</div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 p-4 sm:p-6 overflow-auto">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default AdminPage;
