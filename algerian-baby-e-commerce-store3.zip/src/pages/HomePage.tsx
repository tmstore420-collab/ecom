import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Truck, Shield, CreditCard, Star, HeartHandshake } from 'lucide-react';
import HeroSection from '../components/HeroSection';
import CategorySection from '../components/CategorySection';
import ProductCard from '../components/ProductCard';
import { useStore } from '../store/useStore';
import { useTranslation } from '../hooks/useTranslation';

const HomePage: React.FC = () => {
  const { products } = useStore();
  const { t, language, isRTL } = useTranslation();

  const featuredProducts = products.filter(p => p.featured);
  const latestProducts = [...products].slice(0, 8);

  const features = [
    {
      icon: <Truck className="text-pink-600" size={28} />,
      titleAr: 'توصيل لجميع الولايات',
      titleFr: 'Livraison dans toutes les wilayas',
      descAr: '58 ولاية جزائرية',
      descFr: '58 wilayas algériennes',
      bg: 'bg-pink-50',
      border: 'border-pink-100',
    },
    {
      icon: <CreditCard className="text-purple-600" size={28} />,
      titleAr: 'دفع عند الاستلام',
      titleFr: 'Paiement à la livraison',
      descAr: 'COD فقط • آمن ومضمون',
      descFr: 'COD uniquement • Sûr et garanti',
      bg: 'bg-purple-50',
      border: 'border-purple-100',
    },
    {
      icon: <Shield className="text-blue-600" size={28} />,
      titleAr: 'ضمان الجودة',
      titleFr: 'Garantie qualité',
      descAr: 'منتجات أصلية 100%',
      descFr: 'Produits originaux 100%',
      bg: 'bg-blue-50',
      border: 'border-blue-100',
    },
    {
      icon: <HeartHandshake className="text-rose-600" size={28} />,
      titleAr: 'خدمة عملاء ممتازة',
      titleFr: 'Service client excellent',
      descAr: 'متوفرون على مدار الساعة',
      descFr: 'Disponibles 24/7',
      bg: 'bg-rose-50',
      border: 'border-rose-100',
    },
  ];

  return (
    <div className={`${isRTL ? 'font-cairo' : 'font-poppins'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Hero */}
      <HeroSection />

      {/* Features */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {features.map((f, i) => (
              <div key={i} className={`${f.bg} ${f.border} border rounded-2xl p-5 text-center hover:shadow-lg transition-shadow`}>
                <div className={`w-14 h-14 ${f.bg} rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-sm`}>
                  {f.icon}
                </div>
                <h3 className="font-bold text-gray-800 text-sm mb-1">
                  {language === 'ar' ? f.titleAr : f.titleFr}
                </h3>
                <p className="text-xs text-gray-500">
                  {language === 'ar' ? f.descAr : f.descFr}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <CategorySection />

      {/* Featured Products */}
      {featuredProducts.length > 0 && (
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="flex items-center justify-between mb-10">
              <div>
                <h2 className="text-3xl md:text-4xl font-black text-gray-800">
                  {t('featuredProducts')}
                </h2>
                <p className="text-gray-500 mt-2">
                  {language === 'ar' ? 'أفضل منتجاتنا المختارة لك' : 'Nos meilleurs produits sélectionnés pour vous'}
                </p>
              </div>
              <Link
                to="/products"
                className="hidden md:flex items-center gap-2 text-pink-600 font-bold hover:gap-3 transition-all"
              >
                <span>{t('showMore')}</span>
                {isRTL ? <ArrowLeft size={18} /> : <ArrowRight size={18} />}
              </Link>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
              {featuredProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Promo Banner */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-600 rounded-3xl p-8 md:p-16 text-white text-center relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 bottom-0 opacity-10">
              <div className="absolute top-4 left-4 text-8xl">👶</div>
              <div className="absolute bottom-4 right-4 text-8xl">🎀</div>
              <div className="absolute top-1/2 left-1/4 text-6xl">⭐</div>
              <div className="absolute top-1/3 right-1/4 text-5xl">🌸</div>
            </div>
            <div className="relative z-10">
              <div className="text-5xl mb-4">🎉</div>
              <h2 className="text-3xl md:text-5xl font-black mb-4">
                {language === 'ar' ? 'خصومات حتى 50%' : 'Jusqu\'à 50% de réduction'}
              </h2>
              <p className="text-white/80 text-lg mb-8">
                {language === 'ar' 
                  ? 'على مجموعة مختارة من منتجات الأطفال' 
                  : 'Sur une sélection de produits bébé'}
              </p>
              <Link
                to="/products"
                className="inline-flex items-center gap-2 bg-white text-pink-600 px-10 py-4 rounded-2xl font-black text-lg hover:shadow-xl hover:scale-105 transition-all"
              >
                {language === 'ar' ? 'تسوق الآن' : 'Acheter maintenant'}
                {isRTL ? <ArrowLeft size={20} /> : <ArrowRight size={20} />}
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* All Products */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between mb-10">
            <h2 className="text-3xl md:text-4xl font-black text-gray-800">
              {t('allProducts')}
            </h2>
            <Link
              to="/products"
              className="flex items-center gap-2 text-pink-600 font-bold"
            >
              <span>{t('showMore')}</span>
              {isRTL ? <ArrowLeft size={18} /> : <ArrowRight size={18} />}
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {latestProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-black text-gray-800 mb-3">
              {language === 'ar' ? 'آراء عملائنا' : 'Avis de nos clients'}
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { name: 'أم أحمد', nameF: 'Fatima B.', text: 'منتجات رائعة وجودة عالية. التوصيل كان سريعاً جداً!', textF: 'Produits excellents et haute qualité. La livraison était très rapide!', city: 'الجزائر العاصمة', stars: 5 },
              { name: 'سارة م', nameF: 'Sara M.', text: 'خدمة ممتازة والأسعار مناسبة جداً مقارنة بالمحلات', textF: 'Service excellent et prix très abordables par rapport aux magasins', city: 'وهران', stars: 5 },
              { name: 'نورة ح', nameF: 'Nora H.', text: 'أنصح كل الأمهات بهذا المتجر. منتجات آمنة وجودة عالية', textF: 'Je recommande ce magasin à toutes les mamans. Produits sûrs et qualité élevée', city: 'قسنطينة', stars: 5 },
            ].map((review, i) => (
              <div key={i} className="bg-gradient-to-br from-pink-50 to-purple-50 rounded-2xl p-6 border border-pink-100">
                <div className="flex items-center gap-1 mb-3">
                  {[...Array(review.stars)].map((_, j) => (
                    <Star key={j} size={16} className="text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4 italic">
                  "{language === 'ar' ? review.text : review.textF}"
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-pink-400 to-purple-500 flex items-center justify-center text-white font-bold">
                    {(language === 'ar' ? review.name : review.nameF)[0]}
                  </div>
                  <div>
                    <div className="font-bold text-gray-800">{language === 'ar' ? review.name : review.nameF}</div>
                    <div className="text-xs text-gray-400">{review.city}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center">
                  <span className="text-white font-black">B</span>
                </div>
                <span className="font-black text-xl bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">Baby-care DZ</span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed">
                {language === 'ar' 
                  ? 'متجرك المفضل لكل منتجات الأطفال في الجزائر'
                  : 'Votre boutique préférée pour tous les produits bébé en Algérie'}
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">{language === 'ar' ? 'روابط سريعة' : 'Liens rapides'}</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><Link to="/" className="hover:text-pink-400 transition-colors">{t('home')}</Link></li>
                <li><Link to="/products" className="hover:text-pink-400 transition-colors">{t('products')}</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">{t('delivery')}</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>🚚 {language === 'ar' ? 'توصيل للمنزل' : 'Livraison à domicile'}</li>
                <li>🏢 {language === 'ar' ? 'توصيل لمكتب' : 'Livraison en bureau'}</li>
                <li>📦 COD {language === 'ar' ? 'فقط' : 'uniquement'}</li>
                <li>⏱ 48-72h</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">{t('contact')}</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>📱 WhatsApp</li>
                <li>📘 Facebook</li>
                <li>📸 Instagram</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-500 text-sm">
            <p>© 2025 Baby-care DZ | {language === 'ar' ? 'جميع الحقوق محفوظة' : 'Tous droits réservés'}</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;
