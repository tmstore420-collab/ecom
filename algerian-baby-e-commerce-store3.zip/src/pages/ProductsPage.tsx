import React, { useState, useMemo } from 'react';
import { Search, Filter, X, SlidersHorizontal } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { useStore } from '../store/useStore';
import { useTranslation } from '../hooks/useTranslation';

const ProductsPage: React.FC = () => {
  const { products, categories, searchQuery, setSearchQuery, selectedCategory, setSelectedCategory } = useStore();
  const { t, language, isRTL } = useTranslation();
  const [sortBy, setSortBy] = useState<'newest' | 'priceAsc' | 'priceDesc'>('newest');
  const [filterOpen, setFilterOpen] = useState(false);

  const filteredProducts = useMemo(() => {
    let result = [...products];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(p =>
        p.nameAr.toLowerCase().includes(q) ||
        p.nameFr.toLowerCase().includes(q) ||
        p.descriptionAr.toLowerCase().includes(q) ||
        p.descriptionFr.toLowerCase().includes(q) ||
        (p.tags || []).some(tag => tag.toLowerCase().includes(q))
      );
    }

    if (selectedCategory !== 'all') {
      result = result.filter(p => p.category === selectedCategory);
    }

    if (sortBy === 'priceAsc') {
      result.sort((a, b) => (a.discountPrice || a.price) - (b.discountPrice || b.price));
    } else if (sortBy === 'priceDesc') {
      result.sort((a, b) => (b.discountPrice || b.price) - (a.discountPrice || a.price));
    }

    return result;
  }, [products, searchQuery, selectedCategory, sortBy]);

  return (
    <div className={`min-h-screen bg-gray-50 ${isRTL ? 'font-cairo' : 'font-poppins'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-600 text-white py-16 pt-28 md:pt-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 text-center">
          <h1 className="text-4xl font-black mb-3">
            {t('allProducts')}
          </h1>
          <p className="text-white/80">
            {filteredProducts.length} {language === 'ar' ? 'منتج متوفر' : 'produits disponibles'}
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Search & Controls */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          {/* Search */}
          <div className="relative flex-1">
            <Search size={18} className={`absolute top-1/2 -translate-y-1/2 ${isRTL ? 'right-4' : 'left-4'} text-gray-400`} />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder={t('searchPlaceholder')}
              className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-3 rounded-2xl border-2 border-gray-200 focus:border-pink-400 focus:outline-none bg-white`}
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className={`absolute top-1/2 -translate-y-1/2 ${isRTL ? 'left-4' : 'right-4'} text-gray-400 hover:text-gray-600`}
              >
                <X size={18} />
              </button>
            )}
          </div>

          {/* Sort */}
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value as any)}
            className="px-4 py-3 rounded-2xl border-2 border-gray-200 focus:border-pink-400 focus:outline-none bg-white font-medium text-gray-700"
          >
            <option value="newest">{t('newest')}</option>
            <option value="priceAsc">{t('priceAsc')}</option>
            <option value="priceDesc">{t('priceDesc')}</option>
          </select>

          {/* Filter Toggle (mobile) */}
          <button
            onClick={() => setFilterOpen(!filterOpen)}
            className="md:hidden flex items-center gap-2 px-4 py-3 rounded-2xl border-2 border-gray-200 bg-white font-medium text-gray-700"
          >
            <SlidersHorizontal size={18} />
            {t('filterBy')}
          </button>
        </div>

        <div className="flex gap-6">
          {/* Sidebar Filters */}
          <aside className={`${filterOpen ? 'block' : 'hidden'} md:block w-full md:w-64 shrink-0`}>
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 sticky top-24">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-gray-800 flex items-center gap-2">
                  <Filter size={16} />
                  {t('filterBy')}
                </h3>
                <button
                  onClick={() => { setSelectedCategory('all'); setSearchQuery(''); }}
                  className="text-xs text-pink-500 hover:text-pink-700"
                >
                  {isRTL ? 'مسح الكل' : 'Tout effacer'}
                </button>
              </div>

              <div>
                <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">{t('categories')}</p>
                <div className="space-y-1">
                  <button
                    onClick={() => setSelectedCategory('all')}
                    className={`w-full text-right px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                      selectedCategory === 'all' 
                        ? 'bg-pink-100 text-pink-700' 
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    {t('allCategories')}
                  </button>
                  {categories.map(cat => (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`w-full text-right px-3 py-2.5 rounded-xl text-sm font-medium transition-colors flex items-center gap-2 ${
                        selectedCategory === cat.id 
                          ? 'bg-pink-100 text-pink-700' 
                          : 'text-gray-600 hover:bg-gray-100'
                      }`}
                    >
                      <span>{cat.icon}</span>
                      <span>{language === 'ar' ? cat.labelAr : cat.labelFr}</span>
                      <span className="mr-auto text-xs text-gray-400">
                        ({products.filter(p => p.category === cat.id).length})
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </aside>

          {/* Products Grid */}
          <div className="flex-1">
            {filteredProducts.length === 0 ? (
              <div className="text-center py-20">
                <div className="text-6xl mb-4">🔍</div>
                <h3 className="text-xl font-bold text-gray-700 mb-2">{t('noProducts')}</h3>
                <p className="text-gray-500">
                  {language === 'ar' ? 'جرب كلمات بحث مختلفة' : 'Essayez des mots-clés différents'}
                </p>
                <button
                  onClick={() => { setSearchQuery(''); setSelectedCategory('all'); }}
                  className="mt-4 px-6 py-2 bg-pink-100 text-pink-600 rounded-xl font-medium hover:bg-pink-200 transition-colors"
                >
                  {isRTL ? 'مسح الفلاتر' : 'Effacer les filtres'}
                </button>
              </div>
            ) : (
              <>
                {/* Active Filters */}
                {(selectedCategory !== 'all' || searchQuery) && (
                  <div className="flex flex-wrap gap-2 mb-6">
                    {selectedCategory !== 'all' && (
                      <span className="flex items-center gap-1 bg-pink-100 text-pink-700 px-3 py-1 rounded-full text-sm">
                        {categories.find(c => c.id === selectedCategory)?.[language === 'ar' ? 'labelAr' : 'labelFr']}
                        <button onClick={() => setSelectedCategory('all')}>
                          <X size={14} />
                        </button>
                      </span>
                    )}
                    {searchQuery && (
                      <span className="flex items-center gap-1 bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm">
                        "{searchQuery}"
                        <button onClick={() => setSearchQuery('')}>
                          <X size={14} />
                        </button>
                      </span>
                    )}
                  </div>
                )}
                <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {filteredProducts.map(product => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductsPage;
