import React, { useEffect, useRef, useState } from 'react';
import { useLocation, useParams, Link } from 'react-router-dom';
import { Star, Package, Shield, Truck, Share2 } from 'lucide-react';
import { useStore } from '../store/useStore';
import { useTranslation } from '../hooks/useTranslation';
import CheckoutForm from '../components/CheckoutForm';
import ProductCard from '../components/ProductCard';

const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const location = useLocation();
  const { products, categories } = useStore();
  const { t, language, isRTL } = useTranslation();

  const product = products.find(p => p.id === id);
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedVariations, setSelectedVariations] = useState<Record<string, string>>({});
  const [quantity, setQuantity] = useState(1);
  const [showOrderForm, setShowOrderForm] = useState(false);
  const orderFormRef = useRef<HTMLDivElement | null>(null);

  const openOrderForm = () => {
    setShowOrderForm(true);
    setTimeout(() => {
      orderFormRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 80);
  };

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get('order') === '1') {
      openOrderForm();
    }
  }, [location.search]);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center flex-col gap-4 pt-24">
        <div className="text-6xl">😕</div>
        <h2 className="text-2xl font-bold text-gray-700">
          {isRTL ? 'المنتج غير موجود' : 'Produit introuvable'}
        </h2>
        <Link to="/products" className="px-6 py-3 bg-pink-500 text-white rounded-xl font-bold hover:bg-pink-600 transition-colors">
          {t('backToHome')}
        </Link>
      </div>
    );
  }

  const name = language === 'ar' ? product.nameAr : product.nameFr;
  const description = language === 'ar' ? product.descriptionAr : product.descriptionFr;
  const discount = product.discountPrice
    ? Math.round(((product.price - product.discountPrice) / product.price) * 100)
    : 0;
  const displayPrice = product.discountPrice || product.price;

  const sizeVariations = product.variations.filter(v => v.type === 'size');
  const colorVariations = product.variations.filter(v => v.type === 'color');

  const relatedProducts = products
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const category = categories.find(c => c.id === product.category);

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({ title: name, url: window.location.href });
    } else {
      navigator.clipboard.writeText(window.location.href);
    }
  };

  return (
    <div className={`min-h-screen bg-gray-50 ${isRTL ? 'font-cairo' : 'font-poppins'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Breadcrumb */}
      <div className="bg-white border-b border-gray-100 pt-20 md:pt-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3">
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <Link to="/" className="hover:text-pink-600 transition-colors">{t('home')}</Link>
            <span>/</span>
            <Link to="/products" className="hover:text-pink-600 transition-colors">{t('products')}</Link>
            <span>/</span>
            <span className="text-gray-800 font-medium truncate max-w-[200px]">{name}</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Left: Images */}
          <div className="space-y-4">
            {/* Main Image */}
            <div className={`relative h-80 md:h-[500px] bg-gradient-to-br ${product.bgColor || 'from-pink-50 to-purple-50'} rounded-3xl overflow-hidden`}>
              {product.images[selectedImage] ? (
                <img
                  src={product.images[selectedImage]}
                  alt={name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-8xl">🛍️</div>
              )}
              
              {/* Badges */}
              <div className="absolute top-4 right-4 flex flex-col gap-2">
                {product.badge && (
                  <span className="bg-gradient-to-r from-pink-500 to-purple-600 text-white text-sm font-bold px-4 py-1.5 rounded-full shadow-lg">
                    {product.badge}
                  </span>
                )}
                {discount > 0 && (
                  <span className="bg-red-500 text-white text-sm font-bold px-4 py-1.5 rounded-full shadow-lg">
                    -{discount}%
                  </span>
                )}
              </div>

              {/* Share Button */}
              <button
                onClick={handleShare}
                className="absolute top-4 left-4 w-10 h-10 bg-white/90 rounded-xl flex items-center justify-center shadow-md hover:bg-white transition-colors"
              >
                <Share2 size={18} className="text-gray-600" />
              </button>
            </div>

            {/* Thumbnails */}
            {product.images.length > 1 && (
              <div className="flex gap-3">
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImage(i)}
                    className={`w-20 h-20 rounded-2xl overflow-hidden border-2 transition-all ${
                      selectedImage === i ? 'border-pink-500 scale-105' : 'border-gray-200 opacity-70'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right: Details */}
          <div className="space-y-5 lg:min-h-[500px]">
            {/* Category */}
            {category && (
              <div className="flex items-center gap-2">
                <span className="text-lg">{category.icon}</span>
                <span className="text-sm text-pink-600 font-medium">
                  {language === 'ar' ? category.labelAr : category.labelFr}
                </span>
              </div>
            )}

            {/* Name */}
            <h1 className="text-2xl md:text-3xl font-black text-gray-800 leading-tight">{name}</h1>

            {/* Description */}
            <p className="text-gray-600 text-sm md:text-base leading-relaxed">
              {description}
            </p>

            {/* Rating */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={18} className={i < 4 ? 'text-yellow-400 fill-yellow-400' : 'text-gray-200 fill-gray-200'} />
                ))}
              </div>
              <span className="text-gray-500 text-sm">(127 {isRTL ? 'تقييم' : 'avis'})</span>
            </div>

            {/* Price */}
            <div className="flex items-center gap-4">
              <span className="text-4xl font-black text-pink-600">
                {displayPrice.toLocaleString()} {t('da')}
              </span>
              {product.discountPrice && (
                <div className="flex flex-col">
                  <span className="text-lg text-gray-400 line-through">
                    {product.price.toLocaleString()} {t('da')}
                  </span>
                  <span className="text-sm text-red-500 font-bold">
                    {isRTL ? `وفر ${(product.price - product.discountPrice).toLocaleString()} دج` : `Économisez ${(product.price - product.discountPrice).toLocaleString()} DA`}
                  </span>
                </div>
              )}
            </div>

            {/* Size Variations */}
            {sizeVariations.length > 0 && (
              <div>
                <label className="block font-bold text-gray-700 mb-3">{t('selectSize')}</label>
                <div className="flex flex-wrap gap-2">
                  {sizeVariations.map(v => (
                    <button
                      key={v.id}
                      onClick={() => setSelectedVariations(prev => ({ ...prev, size: v.value }))}
                      disabled={v.stock === 0}
                      className={`px-4 py-2 rounded-xl border-2 font-medium text-sm transition-all ${
                        selectedVariations.size === v.value
                          ? 'border-pink-500 bg-pink-50 text-pink-700'
                          : v.stock === 0
                          ? 'border-gray-200 text-gray-300 cursor-not-allowed line-through'
                          : 'border-gray-200 text-gray-700 hover:border-pink-300'
                      }`}
                    >
                      {language === 'ar' ? v.labelAr : v.labelFr}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Color and quantity in one line */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 items-end">
              {colorVariations.length > 0 && (
                <div>
                  <label className="block font-bold text-gray-700 mb-3">
                    {t('selectColor')}
                    {selectedVariations.color && (
                      <span className="text-pink-600 mr-2 font-normal text-sm">
                        : {colorVariations.find(v => v.value === selectedVariations.color)?.[language === 'ar' ? 'labelAr' : 'labelFr']}
                      </span>
                    )}
                  </label>
                  <div className="flex flex-wrap gap-3">
                    {colorVariations.map(v => (
                      <button
                        key={v.id}
                        onClick={() => setSelectedVariations(prev => ({ ...prev, color: v.value }))}
                        disabled={v.stock === 0}
                        title={language === 'ar' ? v.labelAr : v.labelFr}
                        className={`w-10 h-10 rounded-xl border-4 transition-all ${
                          selectedVariations.color === v.value
                            ? 'border-pink-500 scale-110 shadow-lg'
                            : v.stock === 0
                            ? 'border-gray-200 opacity-30 cursor-not-allowed'
                            : 'border-white shadow-md hover:scale-105 hover:shadow-lg'
                        }`}
                        style={{ backgroundColor: v.value === 'multicolor' ? '#ff69b4' : v.value }}
                      />
                    ))}
                  </div>
                </div>
              )}

              <div>
                <label className="block font-bold text-gray-700 mb-3">{t('quantity')}</label>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setQuantity(q => Math.max(1, q - 1))}
                    className="w-10 h-10 rounded-xl border-2 border-gray-200 flex items-center justify-center text-gray-700 hover:border-pink-300 font-bold text-xl transition-colors"
                  >
                    -
                  </button>
                  <span className="w-12 text-center font-black text-xl text-gray-800">{quantity}</span>
                  <button
                    onClick={() => setQuantity(q => Math.min(product.stock, q + 1))}
                    className="w-10 h-10 rounded-xl border-2 border-gray-200 flex items-center justify-center text-gray-700 hover:border-pink-300 font-bold text-xl transition-colors"
                  >
                    +
                  </button>
                  <span className="text-sm text-gray-500">
                    {product.stock} {isRTL ? 'متوفر' : 'disponibles'}
                  </span>
                </div>
              </div>
            </div>

            {/* Order Button */}
            <div className="space-y-3 pt-1">
            {product.stock > 0 ? (
              <button
                onClick={openOrderForm}
                className="w-full bg-gradient-to-r from-pink-500 to-purple-600 text-white py-4 rounded-2xl font-black text-xl hover:shadow-2xl hover:scale-[1.02] transition-all duration-200 flex items-center justify-center gap-3"
              >
                <span>🛒</span>
                <span>{t('orderNow')}</span>
                <span className="text-lg font-normal">
                  {(displayPrice * quantity).toLocaleString()} {t('da')}
                </span>
              </button>
            ) : (
              <button disabled className="w-full bg-gray-200 text-gray-500 py-4 rounded-2xl font-black text-xl cursor-not-allowed">
                {t('outOfStock')}
              </button>
            )}

            {/* COD Info */}
            <div className="flex items-center justify-center gap-2 text-gray-500 text-sm">
              <span>💰</span>
              <span>{t('codOnly')}</span>
            </div>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { icon: <Truck size={18} className="text-blue-500" />, label: isRTL ? 'توصيل سريع' : 'Livraison rapide' },
                { icon: <Shield size={18} className="text-green-500" />, label: isRTL ? 'جودة مضمونة' : 'Qualité garantie' },
                { icon: <Package size={18} className="text-purple-500" />, label: isRTL ? 'تغليف آمن' : 'Emballage sûr' },
              ].map((badge, i) => (
                <div key={i} className="flex flex-col items-center gap-1 bg-gray-50 rounded-xl p-3 text-center">
                  {badge.icon}
                  <span className="text-xs text-gray-600 font-medium">{badge.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Order Form */}
        {showOrderForm && (
          <div id="order-form" ref={orderFormRef} className="mb-12 scroll-mt-24">
            <div className="bg-white rounded-3xl p-6 md:p-8 shadow-lg border border-pink-100">
              <h2 className="text-2xl font-black text-gray-800 mb-6 flex items-center gap-3">
                <span className="w-8 h-8 bg-gradient-to-br from-pink-500 to-purple-600 rounded-xl flex items-center justify-center text-white text-sm">📋</span>
                {t('orderForm')}
              </h2>
              <CheckoutForm
                product={product}
                selectedVariations={selectedVariations}
                quantity={quantity}
                onSuccess={() => {
                  setShowOrderForm(false);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
              />
            </div>
          </div>
        )}

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div>
            <h2 className="text-2xl font-black text-gray-800 mb-6">{t('relatedProducts')}</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {relatedProducts.map(p => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetailPage;
