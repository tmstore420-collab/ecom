export type Category = string;

export interface StoreCategory {
  id: string;
  labelAr: string;
  labelFr: string;
  icon: string;
  color: string;
}

export interface ProductVariation {
  id: string;
  type: 'size' | 'color';
  value: string;
  labelAr: string;
  labelFr: string;
  stock: number;
  priceModifier?: number;
}

export interface Product {
  id: string;
  nameAr: string;
  nameFr: string;
  descriptionAr: string;
  descriptionFr: string;
  price: number;
  discountPrice?: number;
  images: string[];
  category: Category;
  variations: ProductVariation[];
  stock: number;
  badge?: string;
  bgColor?: string;
  featured?: boolean;
  tags?: string[];
}

export const CATEGORIES: StoreCategory[] = [
  { id: 'baby-clothing', labelAr: 'ملابس الأطفال', labelFr: 'Vêtements Bébé', icon: '👶', color: 'from-pink-400 to-rose-400' },
  { id: 'accessories', labelAr: 'إكسسوارات', labelFr: 'Accessoires', icon: '🎀', color: 'from-purple-400 to-violet-400' },
  { id: 'feeding', labelAr: 'التغذية', labelFr: 'Alimentation', icon: '🍼', color: 'from-blue-400 to-cyan-400' },
  { id: 'nursery', labelAr: 'غرفة الطفل', labelFr: 'Chambre Bébé', icon: '🛏️', color: 'from-green-400 to-emerald-400' },
  { id: 'toys', labelAr: 'ألعاب', labelFr: 'Jouets', icon: '🧸', color: 'from-yellow-400 to-orange-400' },
  { id: 'trendy-accessories', labelAr: 'إكسسوارات عصرية', labelFr: 'Accessoires Tendance', icon: '✨', color: 'from-fuchsia-400 to-pink-400' },
];

export const SAMPLE_PRODUCTS: Product[] = [
  {
    id: '1',
    nameAr: 'بدلة طفل بوتير فاخرة',
    nameFr: 'Combishort Bébé Premium',
    descriptionAr: 'بدلة طفل ناعمة ومريحة 100% قطن عضوي، مثالية للأطفال حديثي الولادة. مصممة للراحة والأناقة مع سحاب سهل الاستخدام.',
    descriptionFr: 'Combishort bébé doux et confortable en 100% coton bio, idéal pour les nouveau-nés. Conçu pour le confort et l\'élégance avec une fermeture éclair facile.',
    price: 2500,
    discountPrice: 1900,
    images: ['/hero-baby.jpg'],
    category: 'baby-clothing',
    variations: [
      { id: 'v1', type: 'size', value: '0-3M', labelAr: '0-3 أشهر', labelFr: '0-3 Mois', stock: 15 },
      { id: 'v2', type: 'size', value: '3-6M', labelAr: '3-6 أشهر', labelFr: '3-6 Mois', stock: 20 },
      { id: 'v3', type: 'size', value: '6-12M', labelAr: '6-12 أشهر', labelFr: '6-12 Mois', stock: 10 },
      { id: 'v4', type: 'color', value: 'pink', labelAr: 'وردي', labelFr: 'Rose', stock: 25 },
      { id: 'v5', type: 'color', value: 'blue', labelAr: 'أزرق', labelFr: 'Bleu', stock: 20 },
      { id: 'v6', type: 'color', value: 'white', labelAr: 'أبيض', labelFr: 'Blanc', stock: 18 },
    ],
    stock: 45,
    badge: 'الأكثر مبيعاً',
    bgColor: 'from-pink-100 to-rose-100',
    featured: true,
    tags: ['cotton', 'newborn', 'soft'],
  },
  {
    id: '2',
    nameAr: 'طقم تغذية شامل',
    nameFr: 'Kit Alimentation Complet',
    descriptionAr: 'طقم تغذية متكامل يشمل: رضاعة، ملعقة، وعاء مع غطاء، مصنوع من مواد آمنة خالية من BPA. مناسب لجميع الأعمار.',
    descriptionFr: 'Kit d\'alimentation complet comprenant : biberon, cuillère, bol avec couvercle, fabriqué en matériaux sûrs sans BPA. Convient à tous les âges.',
    price: 3200,
    discountPrice: 2800,
    images: ['https://images.pexels.com/photos/3662667/pexels-photo-3662667.jpeg?auto=compress&cs=tinysrgb&w=600'],
    category: 'feeding',
    variations: [
      { id: 'v7', type: 'color', value: 'pink', labelAr: 'وردي', labelFr: 'Rose', stock: 15 },
      { id: 'v8', type: 'color', value: 'blue', labelAr: 'أزرق', labelFr: 'Bleu', stock: 15 },
      { id: 'v9', type: 'color', value: 'green', labelAr: 'أخضر', labelFr: 'Vert', stock: 10 },
    ],
    stock: 40,
    badge: 'جديد',
    bgColor: 'from-blue-100 to-cyan-100',
    featured: true,
    tags: ['BPA-free', 'feeding', 'safe'],
  },
  {
    id: '3',
    nameAr: 'دمية أرنب ناعمة',
    nameFr: 'Peluche Lapin Douce',
    descriptionAr: 'دمية أرنب ناعمة وجذابة، مثالية للأطفال من 0 إلى 3 سنوات. مصنوعة من مواد ناعمة وآمنة للأطفال.',
    descriptionFr: 'Peluche lapin douce et attrayante, idéale pour les enfants de 0 à 3 ans. Fabriquée en matériaux doux et sûrs pour les enfants.',
    price: 1800,
    images: ['https://images.pexels.com/photos/35537/child-children-girl-happy.jpg?auto=compress&cs=tinysrgb&w=600'],
    category: 'toys',
    variations: [
      { id: 'v10', type: 'color', value: 'white', labelAr: 'أبيض', labelFr: 'Blanc', stock: 20 },
      { id: 'v11', type: 'color', value: 'gray', labelAr: 'رمادي', labelFr: 'Gris', stock: 15 },
      { id: 'v12', type: 'color', value: 'pink', labelAr: 'وردي', labelFr: 'Rose', stock: 18 },
    ],
    stock: 53,
    bgColor: 'from-yellow-100 to-orange-100',
    featured: false,
    tags: ['toy', 'soft', 'plush'],
  },
  {
    id: '4',
    nameAr: 'حقيبة حفاضات أنيقة',
    nameFr: 'Sac à Langer Élégant',
    descriptionAr: 'حقيبة حفاضات عملية وأنيقة بسعة كبيرة، تحتوي على العديد من الجيوب المنظمة. مناسبة للأمهات العصريات.',
    descriptionFr: 'Sac à langer pratique et élégant avec une grande capacité, contenant de nombreuses poches organisées. Idéal pour les mamans modernes.',
    price: 4500,
    discountPrice: 3800,
    images: ['https://images.pexels.com/photos/1648377/pexels-photo-1648377.jpeg?auto=compress&cs=tinysrgb&w=600'],
    category: 'accessories',
    variations: [
      { id: 'v13', type: 'color', value: 'black', labelAr: 'أسود', labelFr: 'Noir', stock: 10 },
      { id: 'v14', type: 'color', value: 'pink', labelAr: 'وردي', labelFr: 'Rose', stock: 8 },
      { id: 'v15', type: 'color', value: 'beige', labelAr: 'بيج', labelFr: 'Beige', stock: 12 },
    ],
    stock: 30,
    badge: 'عرض خاص',
    bgColor: 'from-purple-100 to-violet-100',
    featured: true,
    tags: ['bag', 'mom', 'stylish'],
  },
  {
    id: '5',
    nameAr: 'سرير أطفال قابل للتحويل',
    nameFr: 'Lit Bébé Convertible',
    descriptionAr: 'سرير أطفال متعدد الوظائف قابل للتحويل إلى سرير أطفال كبار. مصنوع من خشب عالي الجودة خالٍ من المواد الضارة.',
    descriptionFr: 'Lit bébé multifonction convertible en lit enfant. Fabriqué en bois de haute qualité exempt de substances nocives.',
    price: 18000,
    discountPrice: 15000,
    images: ['https://images.pexels.com/photos/1648373/pexels-photo-1648373.jpeg?auto=compress&cs=tinysrgb&w=600'],
    category: 'nursery',
    variations: [
      { id: 'v16', type: 'color', value: 'white', labelAr: 'أبيض', labelFr: 'Blanc', stock: 5 },
      { id: 'v17', type: 'color', value: 'natural', labelAr: 'طبيعي', labelFr: 'Naturel', stock: 7 },
    ],
    stock: 12,
    badge: 'متميز',
    bgColor: 'from-green-100 to-emerald-100',
    featured: true,
    tags: ['nursery', 'bed', 'wood'],
  },
  {
    id: '6',
    nameAr: 'إكسسوارات شعر للأطفال',
    nameFr: 'Accessoires Cheveux Bébé',
    descriptionAr: 'مجموعة إكسسوارات شعر رائعة للأطفال البنات. تشمل أربطة، دبابيس ومشابك ملونة. خامة ناعمة لا تؤذي شعر طفلتك.',
    descriptionFr: 'Magnifique collection d\'accessoires cheveux pour bébés filles. Comprend des élastiques, des épingles et des barrettes colorées. Matière douce qui ne blesse pas les cheveux de votre bébé.',
    price: 800,
    images: ['https://images.pexels.com/photos/35537/child-children-girl-happy.jpg?auto=compress&cs=tinysrgb&w=600'],
    category: 'trendy-accessories',
    variations: [
      { id: 'v18', type: 'color', value: 'multicolor', labelAr: 'متعدد الألوان', labelFr: 'Multicolore', stock: 30 },
      { id: 'v19', type: 'color', value: 'pink', labelAr: 'وردي', labelFr: 'Rose', stock: 25 },
      { id: 'v20', type: 'color', value: 'purple', labelAr: 'بنفسجي', labelFr: 'Violet', stock: 20 },
    ],
    stock: 75,
    bgColor: 'from-fuchsia-100 to-pink-100',
    featured: false,
    tags: ['hair', 'girls', 'accessories'],
  },
  {
    id: '7',
    nameAr: 'بطانية نوم الطفل',
    nameFr: 'Couverture de Sommeil Bébé',
    descriptionAr: 'بطانية نوم فاخرة للطفل، ناعمة ودافئة، مثالية للموسم البارد. مصنوعة من القطن العضوي 100%.',
    descriptionFr: 'Couverture de sommeil luxueuse pour bébé, douce et chaude, idéale pour la saison froide. Fabriquée en 100% coton biologique.',
    price: 2200,
    discountPrice: 1800,
    images: ['https://images.pexels.com/photos/35537/child-children-girl-happy.jpg?auto=compress&cs=tinysrgb&w=600'],
    category: 'nursery',
    variations: [
      { id: 'v21', type: 'size', value: '70x100', labelAr: '70×100 سم', labelFr: '70×100 cm', stock: 20 },
      { id: 'v22', type: 'size', value: '100x150', labelAr: '100×150 سم', labelFr: '100×150 cm', stock: 15 },
      { id: 'v23', type: 'color', value: 'white', labelAr: 'أبيض', labelFr: 'Blanc', stock: 18 },
      { id: 'v24', type: 'color', value: 'pink', labelAr: 'وردي', labelFr: 'Rose', stock: 17 },
    ],
    stock: 35,
    bgColor: 'from-indigo-100 to-blue-100',
    featured: false,
    tags: ['blanket', 'sleep', 'cotton'],
  },
  {
    id: '8',
    nameAr: 'عربة أطفال خفيفة',
    nameFr: 'Poussette Légère',
    descriptionAr: 'عربة أطفال خفيفة الوزن وسهلة الطي، مناسبة للسفر والتسوق. تحتوي على حزام أمان 5 نقاط وسلة تخزين.',
    descriptionFr: 'Poussette légère et facile à plier, idéale pour les voyages et les courses. Comprend une ceinture de sécurité à 5 points et un panier de rangement.',
    price: 22000,
    discountPrice: 18500,
    images: ['https://images.pexels.com/photos/35537/child-children-girl-happy.jpg?auto=compress&cs=tinysrgb&w=600'],
    category: 'accessories',
    variations: [
      { id: 'v25', type: 'color', value: 'black', labelAr: 'أسود', labelFr: 'Noir', stock: 8 },
      { id: 'v26', type: 'color', value: 'gray', labelAr: 'رمادي', labelFr: 'Gris', stock: 6 },
      { id: 'v27', type: 'color', value: 'red', labelAr: 'أحمر', labelFr: 'Rouge', stock: 5 },
    ],
    stock: 19,
    badge: 'الأكثر طلباً',
    bgColor: 'from-slate-100 to-gray-100',
    featured: true,
    tags: ['stroller', 'travel', 'safety'],
  },
];
